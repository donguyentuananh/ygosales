<?php
    session_start();
    require 'config/config.php';
    include 'model/conn.php';
    include 'view/header.php';
    // include 'view/promo.php';
    // include 'view/bestseller.php';
    if(isset($_REQUEST['page'])) {
        $page = $_REQUEST['page'];
        switch($page) {
            // case 'intro':
            //     include 'view/intro.php';
            //     break;
            case 'detailproduct':
                // Check if 'id' parameter is set in the URL
                if (isset($_GET['id'])) {
                    $productId = $_GET['id'];
                    
                    // Fetch and display product details based on $productId
                    $stmt = $conn->prepare("SELECT * FROM product WHERE prd_id = :id");
                    $stmt->bindParam(':id', $productId, PDO::PARAM_INT);
                    $stmt->execute();
                    
                    // Assuming only one product should be fetched, use fetch() instead of fetchAll()
                    $product = $stmt->fetch();

                    if ($product) {
                        // Include the detailproduct.php file and pass the product details
                        include 'view/detailproduct.php';
                    } else {
                        // Handle case where the product with the specified ID is not found
                        echo "Product not found";
                    }
                } else {
                    // Handle case where 'id' parameter is not set in the URL
                    echo "Invalid product ID";
                }
                break;
            case 'payment':
                include 'view/payment.php';
                break;
            // case 'shop':
            //     include 'view/shop.php';
            //     break;
            // case 'single'
            //     include 'view/single.php';
            //     break;  
            case 'login':
                echo "<script> window.location.href='view/login.php';</script>";
                break;
            case 'logout':
                echo "<script> window.location.href='model/logout.php';</script>";
                break;
            case 'admin':
                echo "<script> window.location.href='admin.php';</script>";
                break;  
            case 'user':
                echo "<script> window.location.href='user.php';</script>";
                break;     
            default:
                include 'view/product.php';
                break;
        }
    }
    else include 'view/product.php';
    include 'view/footer.php';
?>