$(document).ready(function(){
    // Ẩn label và div khi trang được tải
    $('label[for="searchTerm"]').hide();
    $('#results').hide();

    $('#searchButton').click(function(){
        performSearch();
    });

    $('#searchTerm').on('keypress', function(e){
        if(e.which === 13){
            e.preventDefault();
            performSearch();
        }
    });

    function performSearch(){
        var searchTerm = $('#searchTerm').val();

        // Thực hiện tìm kiếm
        $.ajax({
            url: '../model/usersearch.php', // Đường dẫn đến file xử lý tìm kiếm phía máy chủ
            method: 'POST',
            data: {term: searchTerm},
            success: function(response){
                // Hiển thị label và results sau khi có kết quả
                $('label[for="searchTerm"]').show();
                $('#results').html(response).show();

            }
        });
    }
});