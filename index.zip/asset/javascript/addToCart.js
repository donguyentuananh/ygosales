document.addEventListener('DOMContentLoaded', function() {
    const cartItemsContainer = document.querySelector('.cart-items');

    function addToCart(productName, productPrice, productImageSrc) {
        const existingCartItem = Array.from(cartItemsContainer.children).find(item => {
            const imageSrc = item.querySelector('img').src;
            return imageSrc === productImageSrc;
        });

        if (existingCartItem) {
            const quantityElement = existingCartItem.querySelector('.quantity');
            const currentQuantity = parseInt(quantityElement.textContent);
            quantityElement.textContent = currentQuantity + 1;
        } else {
            const cartItem = document.createElement('div');
            cartItem.classList.add('cart-item');

            const productImage = document.createElement('img');
            productImage.src = productImageSrc;
            productImage.alt = productName;
            cartItem.appendChild(productImage);

            const productNameElement = document.createElement('span');
            productNameElement.textContent = productName;
            cartItem.appendChild(productNameElement);

            const productPriceElement = document.createElement('label');
            productPriceElement.textContent = productPrice;
            cartItem.appendChild(productPriceElement);

            const quantityElement = document.createElement('div');
            quantityElement.classList.add('quantity');
            quantityElement.textContent = '1';
            cartItem.appendChild(quantityElement);

            const deleteButton = document.createElement('button');
            deleteButton.classList.add('delete-button');
            deleteButton.textContent = 'Xóa';
            deleteButton.addEventListener('click', removeFromCart);
            cartItem.appendChild(deleteButton);

            cartItemsContainer.appendChild(cartItem);
        }

        updateCartCount();
        updateLocalStorage();
    }

    function removeFromCart() {
        const cartItem = this.parentElement;
        const quantityElement = cartItem.querySelector('.quantity');
        const currentQuantity = parseInt(quantityElement.textContent);

        if (currentQuantity > 1) {
            quantityElement.textContent = currentQuantity - 1;
        } else {
            cartItem.remove();
        }

        updateCartCount();
        updateLocalStorage();
    }

    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productBox = this.parentElement;
            const productName = productBox.querySelector('span').textContent;
            const productPrice = productBox.querySelector('label').textContent;
            const productImageSrc = productBox.querySelector('img').src;
            addToCart(productName, productPrice, productImageSrc);
        });
    });

    function updateCartCount() {
        const cartItems = document.querySelectorAll('.cart-item');
        const cartCount = cartItems.length;
        let cartTotal = 0;

        cartItems.forEach(item => {
            const priceString = item.querySelector('label').textContent;
            const price = parseFloat(priceString.replace(' VND', '').replace(',', ''));
            const quantity = parseInt(item.querySelector('.quantity').textContent);
            cartTotal += (price * quantity);
        });

        const cartButton = document.querySelector('.btn-cart');
        cartButton.textContent = `${cartCount} Sản Phẩm - ${cartTotal.toFixed(3).replace(/\d(?=(\d{3})+\.)/g, '$&,')} VNĐ`;
    }

    function updateLocalStorage() {
        const cartItems = document.querySelectorAll('.cart-item');
        const cartData = [];

        cartItems.forEach(item => {
            const productName = item.querySelector('span').textContent;
            const productPrice = item.querySelector('label').textContent;
            const productImageSrc = item.querySelector('img').src;
            const quantity = parseInt(item.querySelector('.quantity').textContent);

            const cartItem = {
                productName: productName,
                productPrice: productPrice,
                productImageSrc: productImageSrc,
                quantity: quantity
            };

            cartData.push(cartItem);
        });

        localStorage.setItem('cartItems', JSON.stringify(cartData));
    }

    // Cập nhật giỏ hàng từ localStorage khi trang web được nạp lại
    function loadCartFromLocalStorage() {
        const cartData = JSON.parse(localStorage.getItem('cartItems')) || [];

        cartData.forEach(item => {
            addToCart(item.productName, item.productPrice, item.productImageSrc);
            const quantityElement = cartItemsContainer.querySelector(`img[src="${item.productImageSrc}"]`).parentElement.querySelector('.quantity');
            quantityElement.textContent = item.quantity;
        });
    }

        loadCartFromLocalStorage();
    });

    