function updateCartInfo() {
    // Send an AJAX request to retrieve cart information from the server
    $.ajax({
        url: '../model/cart_info.php', // Adjust the path based on your project structure
        method: 'GET',
        dataType: 'json', // Specify JSON as the expected response type
        success: function(cartInfo) {

            // Function to format a number with dots for every three digits
            function formatNumberWithDots(number) {
                return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            }

            // Use the custom function to format the total price
            var formattedTotalPrice = formatNumberWithDots(cartInfo.totalPrice);

            // Update the cart button content with the new quantity and formatted total price
            $('#cart-info').text(cartInfo.totalQuantity + ' Sản Phẩm - ' + formattedTotalPrice + '.000 VND');
            
        },
        error: function(error) {
            // Handle errors (if needed)
            console.error(error);
        }
    });
}

// Call the function on page load to initially update the cart information
$(document).ready(function() {
    updateCartInfo();
});