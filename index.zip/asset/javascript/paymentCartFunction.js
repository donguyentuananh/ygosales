document.addEventListener('DOMContentLoaded', function () {
    var selectAllCheckbox = document.getElementById('selectAllCheckbox');
    var productCheckboxes = document.querySelectorAll('.content-cart-product input[type="checkbox"]');

    selectAllCheckbox.addEventListener('change', function () {
        productCheckboxes.forEach(function (checkbox) {
            checkbox.checked = selectAllCheckbox.checked;
        });
        updateTotalSum();
    });

    $('.quantity-input').on('change', function () {
        updateTotalSum();
        // ... existing code
    });

    $('.cart-item-checkbox').on('change', function () {
        updateTotalSum();
        // ... existing code
    });

    $('#deleteButton').on('click', function () {
        deleteSelected();
    });

    function formatNumber(number) {
        return number.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }

    function updateTotalSum() {
        var totalSum = 0;
        var addedConstant = false; // Flag to check if the constant has been added
    
        productCheckboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                var quantity = parseFloat(checkbox.closest('.content-cart-product').querySelector('.quantity-input').value);
                var price = parseFloat(checkbox.closest('.content-cart-product').querySelector('label').textContent);
    
                // Check if the constant has been added
                if (!addedConstant) {
                    totalSum += 30;
                    addedConstant = true; // Set the flag to true
                }
    
                totalSum += quantity * price;
            }
        });
    
        var formattedTotalSum = formatNumber(totalSum);
        $('#totalSumDisplay').text('Tổng thanh toán: ' + formattedTotalSum + '.000 VND');
    }

    function deleteSelected() {
        var cartItemIDs = [];
        productCheckboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                cartItemIDs.push(checkbox.closest('.content-cart-product').dataset.cartId);
            }
        });

        if (cartItemIDs.length > 0) {
            $.ajax({
                type: 'POST',
                url: '../model/deletepaymentcart.php',
                data: { cartItemIDs: cartItemIDs },
                success: function (response) {
                    console.log(response);

                    location.reload();
                    
                    productCheckboxes.each(function () {
                        if ($(this).is(':checked')) {
                            $(this).closest('.content-cart-product').remove();
                        }
                    });

                    updateTotalSum();

                },
                error: function (error) {
                    console.error(error);
                }
            });
        }
    }
});