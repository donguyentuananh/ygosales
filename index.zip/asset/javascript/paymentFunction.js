function submitPayment() {
    // Gather data from the form
    var address = document.querySelector('input[name="address"]').value;
    var phoneNumber = document.querySelector('input[name="phone_number"]').value;
    var paymentMethod = document.getElementById('payment_method').value;
    var note = document.getElementById('note').value;

    // Get all selected cart item elements
    var selectedCartItems = document.querySelectorAll('.cart-item-checkbox:checked');

    // Prepare an array to store cart item data
    var cartItemsData = [];

    // Iterate over selected cart items
    selectedCartItems.forEach(function (item) {
        var cartItemId = item.getAttribute('data-cart-id');
        var quantityInput = document.querySelector('.quantity-input[data-cart-id="' + cartItemId + '"]');
        var quantityValue = quantityInput ? quantityInput.value : 0; // Default to 0 if not found

        // Push data for each cart item to the array
        cartItemsData.push({
            cartItemId: cartItemId,
            quantity: quantityValue
        });
    });

    // Make an AJAX request to your server-side script
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Handle the response
                console.log(xhr.responseText);

                // Check if the response indicates success (you might need to customize this part based on your server's response)
                if (xhr.responseText.trim() === "Payment successful!") {
                    // Show success message
                    alert('Thanh toán thành công!');
                    // You can add any additional actions here if needed

                    // Reload the page to update information
                    location.reload();
                } else {
                    // Handle other cases or errors
                    alert('Có lỗi xảy ra trong quá trình thanh toán.');
                }
            } else {
                // Handle errors
                console.error('Error:', xhr.status);
            }
        }
    };

    // Prepare the data to be sent
    var formData = new FormData();
    formData.append('address', address);
    formData.append('phone_number', phoneNumber);
    formData.append('payment_method', paymentMethod);
    formData.append('note', note);
    formData.append('cart_items_data', JSON.stringify(cartItemsData)); // Send cart items data as an array

    // Send the request to your server-side script (replace '../model/paymentprocess.php' with your actual script)
    xhr.open('POST', '../model/paymentprocess.php', true);
    xhr.send(formData);
}