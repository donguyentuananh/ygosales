document.addEventListener('DOMContentLoaded', function() {
    const cartButton = document.querySelector('.btn-cart');
    const cartDropdown = document.querySelector('.cart-dropdown');

    // Check if the flag is set in local storage and show/hide the cart dropdown accordingly
    if (localStorage.getItem('cartDropdownVisible') === 'true') {
        showCartDropdown();
    } else {
        hideCartDropdown();
    }

    cartButton.addEventListener('click', function() {
        // Toggle the 'active' class on the cart dropdown
        cartDropdown.classList.toggle('active');

        // Update the flag in local storage based on the current visibility state
        localStorage.setItem('cartDropdownVisible', cartDropdown.classList.contains('active'));
    });

    // Function to show the cart dropdown
    function showCartDropdown() {
        // Show the cart dropdown
        cartDropdown.classList.add('active');
    }

    // Function to hide the cart dropdown
    function hideCartDropdown() {
        // Hide the cart dropdown
        cartDropdown.classList.remove('active');
    }

    $('.delete-button').on('click', function() {
        var cartID = $(this).closest('.cart-item').data('cart-id');

        $.ajax({
            url: '../model/deletecart_process.php',
            method: 'POST',
            data: { cartID: cartID },
            success: function(response) {
                console.log(response);

                // Reload the page
                location.reload();
            },
            error: function(error) {
                console.error(error);
            }
        });
    });
});