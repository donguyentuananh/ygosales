<?php
    session_start();

    include '../config/config.php';
    include 'conn.php'; // Include your database configuration

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cartID'])) {
        $cartID = $_POST['cartID'];

        // Assuming you have a database connection ($conn) established
        try {
            // Check the current quantity
            $quantityQuery = $conn->prepare("SELECT quantity FROM addtocart WHERE cartID = ?");
            $quantityQuery->execute([$cartID]);
            $currentQuantity = $quantityQuery->fetchColumn();

            // If quantity is 1, delete the item
            if ($currentQuantity == 1) {
                $deleteQuery = $conn->prepare("DELETE FROM addtocart WHERE cartID = ?");
                $deleteQuery->execute([$cartID]);

                echo 'Item deleted successfully'; // Send a response back to the client
                die(); // Terminate the script // Send a response back to the client
            } else {
                // If quantity is more than 1, update the quantity
                $updateQuery = $conn->prepare("UPDATE addtocart SET quantity = GREATEST(quantity - 1, 0) WHERE cartID = ?");
                $updateQuery->execute([$cartID]);

                echo 'Item update successfully'; // Send a response back to the client
                die(); // Terminate the script // Send a response back to the client
            }
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    } else {
        // Handle invalid requests (if needed)
        echo 'Invalid request';
    }
?>