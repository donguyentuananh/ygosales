<?php
    session_start();

    include '../config/config.php';
    include 'conn.php'; // Include your database configuration

    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    if ($user_id) {
        try {
            // Retrieve total quantity and total price for the user's cart
            $stmt = $conn->prepare("SELECT SUM(quantity) as totalQuantity, SUM(price * quantity) as totalPrice FROM addtocart WHERE usrID = ?");
            $stmt->execute([$user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            // Return the result as JSON
            echo json_encode($result);
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    } else {
        // Handle the case where user_id is not set in the session
        echo json_encode(['totalQuantity' => 0, 'totalPrice' => 0]);
    }
?>