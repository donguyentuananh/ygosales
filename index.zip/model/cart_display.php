<?php
    session_start();

    // Include the cart_operations script
    require 'cart_operations.php';

    // Retrieve cart items
    $cartItems = getCartItems();

    // Display cart items
    foreach ($cartItems as $item) {
        echo '<div class="cart-item">' . $item['product_name'] . ' - ' . $item['product_price'] . ' VND</div>';
    }
?>