<?php

    require '../config/config.php';
    include 'conn.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cartIds = $_POST["cartIds"];
        $selectedStatus = $_POST["selectedStatus"];

            // Use prepared statements to prevent SQL injection
            $updateStmt = $conn->prepare("UPDATE cart SET waiting = ? WHERE cart_id IN (" . implode(",", array_fill(0, count($cartIds), "?")) . ")");
            $updateStmt->bindValue(1, $selectedStatus);

            foreach ($cartIds as $index => $cartId) {
                $updateStmt->bindValue($index + 2, $cartId);
            }

            // Execute the update statement
            $updateStmt->execute();

            // After successful update, insert into buyhistory
            $insertStmt = $conn->prepare("INSERT INTO buyhistory (usrID, prdID, image_prd, name_prd, quantity_prd, price_prd) SELECT usrID, prdID, image_prd, name_prd, quantity, prd_price FROM cart WHERE cart_id IN (" . implode(",", array_fill(0, count($cartIds), "?")) . ")");
            
            foreach ($cartIds as $index => $cartId) {
                $insertStmt->bindValue($index + 1, $cartId);
            }

            // Execute the insert statement
            $insertStmt->execute();

            // Delete rows from cart
            $deleteStmt = $conn->prepare("DELETE FROM cart WHERE cart_id IN (" . implode(",", array_fill(0, count($cartIds), "?")) . ")");
            
            foreach ($cartIds as $index => $cartId) {
                $deleteStmt->bindValue($index + 1, $cartId);
            }

            // Execute the delete statement
            $deleteStmt->execute();

            // Return a response if needed
            echo "Update, insert, and delete successful!";
        }
        
?>