<?php
    session_start();
        if (isset($_SESSION['username'])){
            // session_destroy();
            session_unset();

            
        // setcookie('usr','usr',time() - 1,'/');
        // setcookie('img','img',time() - 1,'/');
        }
    header('location:../index.php');
?>