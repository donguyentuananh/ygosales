<?php
    require '../config/config.php';
    include 'conn.php';

    // Check if the request is a POST request
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Get the cart ID and new quantity from the POST data
        $cart_id = isset($_POST['cart_id']) ? $_POST['cart_id'] : null;
        $new_quantity = isset($_POST['new_quantity']) ? $_POST['new_quantity'] : null;

        if ($cart_id !== null && $new_quantity !== null) {
            if ($new_quantity < 1) {
                // Use prepared statement to remove the product from the database
                $stmt = $conn->prepare("DELETE FROM addtocart WHERE cartID = ?");
                $stmt->bindParam(1, $cart_id, PDO::PARAM_INT);

                // Execute the statement
                if ($stmt->execute()) {
                    // Return a success message or any other response if needed
                    echo json_encode(['status' => 'success', 'message' => 'Product removed successfully']);
                } else {
                    // Return an error message or any other response if the removal fails
                    echo json_encode(['status' => 'error', 'message' => 'Error removing product']);
                }
            } else {
                // Use prepared statement to update the quantity in the database
                $stmt = $conn->prepare("UPDATE addtocart SET quantity = ? WHERE cartID = ?");
                $stmt->bindParam(1, $new_quantity, PDO::PARAM_INT);
                $stmt->bindParam(2, $cart_id, PDO::PARAM_INT);

                // Execute the statement
                if ($stmt->execute()) {
                    // Return a success message or any other response if needed
                    echo json_encode(['status' => 'success', 'message' => 'Quantity updated successfully']);
                } else {
                    // Return an error message or any other response if the update fails
                    echo json_encode(['status' => 'error', 'message' => 'Error updating quantity']);
                }
            }
        } else {
            // Return an error message if cart_id or new_quantity is not provided
            echo json_encode(['status' => 'error', 'message' => 'Cart ID or new quantity not provided']);
        }
    } else {
        // Return an error message if the request method is not POST
        echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    }
?>