<?php
    // Kết nối CSDL
    require '../config/config.php';
    include 'conn.php';

    try {
    
        $searchTerm = $_POST['term'];
        $stmt = $conn->prepare("SELECT * FROM comment WHERE name LIKE :term");
        $stmt->bindValue(':term', '%' . $searchTerm . '%', PDO::PARAM_STR);
        $stmt->execute();
    
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        if ($result) {
            foreach ($result as $row) {
                echo '                
                <div class="user-content" align="center">
                    <span>' . $row['cmt_id'] . '</span>
                    <span>' . $row['name'] . '</span>
                    <span>' . $row['usrID'] . '</span>
                    <span>' . $row['prdID'] . '</span>
                    <span>' . $row['cmt'] . '</span>
                    <button class="delete-btn" data-cmtid="' . $row['cmt_id'] . '">
                        Delete
                    </button>
                </div>
                ';    
            }
        } else {
            echo "Không tìm thấy comment.";
        }
    } catch(PDOException $e) {
        echo "Lỗi kết nối: " . $e->getMessage();
    }
    
    $conn = null;

?>