<?php
    // Kết nối CSDL
    require '../config/config.php';
    include 'conn.php';

    try {
    
        $searchTerm = $_POST['term'];
        $stmt = $conn->prepare("SELECT * FROM product WHERE name LIKE :term");
        $stmt->bindValue(':term', '%' . $searchTerm . '%', PDO::PARAM_STR);
        $stmt->execute();
    
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        if ($result) {
            foreach ($result as $row) {
                echo '                
                <div class="card-box2">
                    <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">
                        <img src="../asset/image/' . $row['image'] . '.jpg" alt="Hộp thẻ bài Yugioh">
                    </a>                            
                    <span>
                        <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                    </span>                            
                    <label>
                        <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">' . $row['price'] . ' VND</a>
                    </label>                           
                    <button class="add-to-cart delete-product" data-product-image="' . $row['image'] . '">Xóa</button>
                    <a class="update-btn" href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">Sửa</a>
                </div>
                ';    
            }
        } else {
            echo "Không tìm thấy sản phẩm.";
        }
    } catch(PDOException $e) {
        echo "Lỗi kết nối: " . $e->getMessage();
    }
    
    $conn = null;

?>