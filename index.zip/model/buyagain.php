<?php

    include '../config/config.php';
    include 'conn.php'; // Include your database configuration

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve data from the AJAX request
        $bhId = $_POST['bhId'];

        // Retrieve other data from the database based on $bhId, assuming $conn is your database connection
        $selectQuery = "SELECT * FROM buyhistory WHERE BH_id = '$bhId'"; // Update with the appropriate condition
        $result = $conn->query($selectQuery);

        if ($result && $row = $result->fetch()) {
            $prdID = $row['prdID']; // Update with the actual column name
            $usrID = $row['usrID']; // Assuming you have the user ID in the session
            $image = $row['image_prd']; // Update with the actual column name
            $name = $row['name_prd']; // Update with the actual column name
            $price = $row['price_prd'] . '.000'; // Update with the actual column name
            $quantity = $row['quantity_prd']; // Update with the actual column name

            // Perform the database insertion
            $insertQuery = "INSERT INTO addtocart (prdID, usrID, image, name, price, quantity) 
                            VALUES ('$prdID', '$usrID', '$image', '$name', '$price', '$quantity')";
            $conn->query($insertQuery);

            // You can send a response back to the JavaScript if needed
            echo 'Insertion successful';
        } else {
            // Handle database query error
            http_response_code(500);
            echo 'Error retrieving data from buyhistory';
        }
    } else {
        // Handle invalid request method
        http_response_code(400);
        echo 'Invalid request method';
    }

?>