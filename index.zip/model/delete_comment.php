<?php

    require '../config/config.php';
    include 'conn.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['cmt_id'])) {
            $cmtId = $_POST['cmt_id'];

            // Perform the deletion in the database
            $deleteStmt = $conn->prepare("DELETE FROM comment WHERE cmt_id = ?");
            $deleteStmt->execute([$cmtId]);

            // Send a response back to the client (optional)
            echo json_encode(['success' => true]);
        }
    }
?>