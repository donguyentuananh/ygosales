<?php
    session_start();

    include '../config/config.php';  // Include your database configuration
    include 'conn.php';             // Include your database connection

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_comment'])) {
        $prd_id = $_POST['prd_id'];
        $username = $_POST['username'];
        $user_id = $_POST['user_id'];
        $comment = $_POST['comment'];

        // Validate and sanitize data as needed
        $comment = htmlspecialchars($comment, ENT_QUOTES, 'UTF-8');

        if (empty($comment)) {
            // Comment is empty, do not proceed with the insert
            echo '<script>alert("Vui lòng nhập bình luận.");';
            echo "window.location.href = '../index.php?page=detailproduct&id=$prd_id';</script>";
            exit();
        }

        try {
            // Prepare and execute the SQL query
            $stmt = $conn->prepare("INSERT INTO comment (name, usrID, prdID, cmt) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $user_id, $prd_id, $comment]);

            // Redirect or perform any other action after successful insertion
            echo "<script>window.location.href = '../index.php?page=detailproduct&id=$prd_id'</script>;";
            exit();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        } finally {
            $conn = null;
        }
    }