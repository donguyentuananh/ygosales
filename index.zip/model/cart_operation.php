<?php
    session_start();

    function addToCart($product) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Check if the product is already in the cart
        $index = array_search($product['product_id'], array_column($_SESSION['cart'], 'product_id'));

        if ($index !== false) {
            // Increment quantity if the product is already in the cart
            $_SESSION['cart'][$index]['quantity']++;
        } else {
            // Add the product to the cart with a quantity of 1
            $product['quantity'] = 1;
            $_SESSION['cart'][] = $product;
        }
    }

    function getCartItems() {
        return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
    }

    // Example: Handle different cart operations
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($_POST['action'] === 'add') {
            $product = [
                'user_id' => $_POST['user_id'],
                'product_id' => $_POST['product_id'],
                'product_name' => $_POST['product_name'],
                'product_price' => $_POST['product_price'],
                'product_image' => $_POST['product_image'],
            ];

            addToCart($product);
        }
    }
?>