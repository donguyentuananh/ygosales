<?php
    require '../config/config.php';
    include 'conn.php';
     // Kết nối CSDL (thay đổi tên file và nội dung tùy thuộc vào cấu trúc của bạn)

     if (isset($_POST['update_submit'])) {
        $user_id = $_POST['user_id'];
        $update_name = $_POST['update_name'];
        $update_username = $_POST['update_username'];
        $update_email = $_POST['update_email'];
        $update_confirm = $_POST['update_confirm'];
        $update_role = $_POST['update_role'];
        $update_status = $_POST['update_status'];
        $update_address = $_POST['update_address'];
        $update_phonenumber = $_POST['update_phonenumber'];
    
        // Mã hóa mật khẩu bằng bcrypt
        $hashed_password = password_hash($update_confirm, PASSWORD_BCRYPT);
    
        try {
            // Chuẩn bị câu truy vấn SQL UPDATE
            $query = "UPDATE user SET 
                      name = :update_name, 
                      username = :update_username, 
                      email = :update_email, 
                      password = :hashed_password, 
                      confirm = :update_confirm, 
                      role = :update_role, 
                      status = :update_status 
                      WHERE user_id = :user_id";
    
            // Thực hiện câu truy vấn và kiểm tra kết quả
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':update_name', $update_name);
            $stmt->bindParam(':update_username', $update_username);
            $stmt->bindParam(':update_email', $update_email);
            $stmt->bindParam(':hashed_password', $hashed_password);
            $stmt->bindParam(':update_confirm', $update_confirm);
            $stmt->bindParam(':update_role', $update_role);
            $stmt->bindParam(':update_status', $update_status);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->execute();

            $query2 = "UPDATE userinfor SET address = :update_address, phone_number = :update_phonenumber WHERE usrID = :user_id";
            $stmt = $conn->prepare($query2);
            $stmt->bindParam(':update_address', $update_address);
            $stmt->bindParam(':update_phonenumber', $update_phonenumber);
            $stmt->bindParam(':user_id', $user_id); // Make sure to bind user_id as well
            $stmt->execute();
    
            echo '<script>alert("User updated successfully.");';
            echo "window.location.href = '../admin.php?page=updateuser&id=$user_id';</script>";
        } catch (PDOException $e) {
            echo "Lỗi: " . $e->getMessage();
        }
    } else {
        echo "Không có dữ liệu gửi đi.";
    }
?>