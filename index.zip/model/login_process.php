<?php
    session_start(); 
    
    require '../config/config.php';
    require 'conn.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
        $stmt->bindParam(1, $username);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($user['status'] == 'lock') {
                echo "<script>
                        alert('Tài khoản của quý khách đã bị khóa.');
                        window.location.href='../view/login.php';
                    </script>"; // Chuyển hướng đến trang đăng nhập lại
                exit();
            }

            if (password_verify($password, $user['password'])) {
                // Đăng nhập thành công
                $_SESSION['user_id'] = $user['user_id']; // Add this line to store user_id in the session
                $_SESSION['username'] = $user['name'];

                if ($user['role'] == "admin") {
                    $_SESSION['role'] = "admin";
                    echo "<script>
                            alert('Đăng nhập tài khoản Admin.');
                            window.location.href='../index.php';
                        </script>";
                } else {
                    $_SESSION['role'] = "user";
                    echo "<script>
                            alert('Đăng nhập thành công.');
                            window.location.href='../index.php';
                        </script>";
                }
                // header("location: ../index.php"); // Chuyển hướng đến trang chào mừng sau khi đăng nhập thành công
                exit();
            } else {
                echo "  <script>
                            alert('Mật khẩu không đúng, vui lòng thử lại.');
                            window.location.href='../view/login.php';
                        </script>"; // Chuyển hướng đến trang đăng nhập lại
                exit();
            }
        } else {
            echo "      <script>
                            alert('Username không đúng, vui lòng thử lại.');
                            window.location.href='../view/login.php';
                        </script>"; // Chuyển hướng đến trang đăng nhập lại
            exit();
        }
    } else {
        echo "Invalid request method";
        exit();
    }

    $conn = null;
    
?>