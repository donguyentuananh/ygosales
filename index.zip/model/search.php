<?php

    session_start();

    // Kết nối CSDL
    require '../config/config.php';
    include 'conn.php';

    try {
    
        $searchTerm = $_POST['term'];
        // Retrieve user_id from the session
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        $stmt = $conn->prepare("SELECT * FROM product WHERE name LIKE :term");
        $stmt->bindValue(':term', '%' . $searchTerm . '%', PDO::PARAM_STR);
        $stmt->execute();
    
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        if ($result) {
            foreach ($result as $row) {
                echo '                
                        <div class="card-box">
                            <form class="add-to-cart-form">
                                <input type="hidden" name="user_id" value="' . $user_id . '">
                                <input type="hidden" name="product_id" value="' . $row['prd_id'] . '">
                                <input type="hidden" name="product_name" value="' . $row['name'] . '">
                                <input type="hidden" name="product_price" value="' . $row['price'] . '">
                                <input type="hidden" name="product_image" value="' . $row['image'] . '">
                                <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">
                                    <img src="asset/image/' . $row['image'] . '.jpg" alt="Hộp thẻ bài Yugioh">
                                </a>
                                <span>
                                    <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                </span>
                                <label>
                                    <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['price'] . ' VND</a>
                                </label>
                                <button type="button" class="add-to-cart">+</button>
                            </form>
                        </div>
                ';    
            }
        } else {
            echo "Không tìm thấy sản phẩm.";
        }
    } catch(PDOException $e) {
        echo "Lỗi kết nối: " . $e->getMessage();
    }
    
    $conn = null;

?>