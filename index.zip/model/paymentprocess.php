<?php

    session_start();

    require '../config/config.php';
    include 'conn.php';

    // Assuming you have a database connection established ($conn)

    // Retrieve data from the AJAX request
    $address = $_POST['address'];
    $phoneNumber = $_POST['phone_number'];
    $paymentMethod = $_POST['payment_method'];
    $note = $_POST['note'];
    $cartItemsData = json_decode($_POST['cart_items_data'], true); // Decode JSON array

    // Guest name from session (replace 'guest_name_session_key' with the actual session key)
    $guestName = isset($_SESSION['username']) ? $_SESSION['username'] : '';
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';

    // Calculate total delivery cost and set default values
    $deliveryCost = 30;
    $status = ($paymentMethod === 'banking') ? 'paid' : 'unpaid';
    $waiting = ($paymentMethod === 'banking') ? 'accept' : 'unaccept';

    // Initialize totalSum
    $totalSum = 0;

    // Process each cart item
    foreach ($cartItemsData as $cartItem) {
        $cartItemId = $cartItem['cartItemId'];
        $quantity = $cartItem['quantity'];

        // Fetch other necessary data for each item (you might need to modify this part)
        $stmt = $conn->prepare("SELECT * FROM addtocart WHERE cartID = ?");
        $stmt->bindParam(1, $cartItemId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch();

        // Calculate total price for each item
        $total_price = $quantity * $row['price'];
        $totalSum += $total_price + $deliveryCost;

        // Insert data into the 'cart' table
        $stmtInsertCart = $conn->prepare("
            INSERT INTO cart 
            (prdID, usrID, guest_name, quantity, phonenumber, address, payment, prd_price, total_prd_price, dilivery_cost, total, note, status, image_prd, name_prd, waiting)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        // Retrieve data for each item
        $stmtInsertCart->bindParam(1, $row['prdID'], PDO::PARAM_INT); // Sử dụng prdID từ bảng addtocart
        $stmtInsertCart->bindParam(2, $user_id, PDO::PARAM_INT);
        $stmtInsertCart->bindParam(3, $guestName, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(4, $quantity, PDO::PARAM_INT);
        $stmtInsertCart->bindParam(5, $phoneNumber, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(6, $address, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(7, $paymentMethod, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(8, $row['price'], PDO::PARAM_INT);
        $stmtInsertCart->bindParam(9, $total_price, PDO::PARAM_INT);
        $stmtInsertCart->bindParam(10, $deliveryCost, PDO::PARAM_INT);
        $stmtInsertCart->bindParam(11, $totalSum, PDO::PARAM_INT);
        $stmtInsertCart->bindParam(12, $note, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(13, $status, PDO::PARAM_STR);
        $stmtInsertCart->bindParam(14, $row['image'], PDO::PARAM_STR);
        $stmtInsertCart->bindParam(15, $row['name'], PDO::PARAM_STR);
        $stmtInsertCart->bindParam(16, $waiting, PDO::PARAM_STR);

        // Execute the query to insert into 'cart' table
        $stmtInsertCart->execute();

        // Delete the corresponding row from 'addtocart' table
        $stmtDeleteFromAddToCart = $conn->prepare("DELETE FROM addtocart WHERE cartID = ?");
        $stmtDeleteFromAddToCart->bindParam(1, $cartItemId, PDO::PARAM_INT);
        $stmtDeleteFromAddToCart->execute();

        // Check if usrID already exists in 'userinfor' table
        $checkUserStmt = $conn->prepare("SELECT COUNT(*) FROM userinfor WHERE usrID = ?");
        $checkUserStmt->bindParam(1, $user_id, PDO::PARAM_INT);
        $checkUserStmt->execute();
        $userExists = $checkUserStmt->fetchColumn();

        if (!$userExists) {
            // usrID doesn't exist, insert data into 'userinfor' table
            $stmtInsertUserInfor = $conn->prepare("
                INSERT INTO userinfor (usrID, address, phone_number)
                VALUES (?, ?, ?)
            ");
            $stmtInsertUserInfor->bindParam(1, $user_id, PDO::PARAM_INT);
            $stmtInsertUserInfor->bindParam(2, $address, PDO::PARAM_STR);
            $stmtInsertUserInfor->bindParam(3, $phoneNumber, PDO::PARAM_STR);
            $stmtInsertUserInfor->execute();
        } else {
            // usrID already exists, handle accordingly (maybe update the existing record or show a message)
            // For now, let's just log a message
            error_log("usrID already exists in 'userinfor' table. Not inserting again.");
        }
    }

    // Send a response back to the client (you can customize this based on your needs)
    echo "Payment successful!";
?>