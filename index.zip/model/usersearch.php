<?php
    // Kết nối CSDL
    require '../config/config.php';
    include 'conn.php';

    try {
    
        $searchTerm = $_POST['term'];
        $stmt = $conn->prepare("SELECT * FROM user WHERE name LIKE :term");
        $stmt->bindValue(':term', '%' . $searchTerm . '%', PDO::PARAM_STR);
        $stmt->execute();
    
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        if ($result) {
            foreach ($result as $row) {
                echo '                
                    <div class="user-content" align="center">
                        <span>' . $row['user_id'] . '</span>
                        <span>' . $row['name'] . '</span>
                        <span>' . $row['username'] . '</span>
                        <span>' . $row['email'] . '</span>
                        <span>' . $row['confirm'] . '</span>
                        <span>' . $row['role'] . '</span>
                        <span>' . $row['status'] . '</span>
                        <span>
                            <a href="admin.php?page=updateuser&id=' . $row['user_id'] . '">Edit</a>
                        </span>
                    </div>
                ';    
            }
        } else {
            echo "Không tìm thấy người dùng.";
        }
    } catch(PDOException $e) {
        echo "Lỗi kết nối: " . $e->getMessage();
    }
    
    $conn = null;

?>