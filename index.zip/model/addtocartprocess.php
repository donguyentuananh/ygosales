<?php

    session_start();

    include '../config/config.php';
    include 'conn.php'; // Include your database configuration

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id']) && isset($_POST['product_id'])) {
        $user_id = $_POST['user_id'];
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_image = $_POST['product_image'];
        $quantity = 1;

        try {
            // Check if the product is already in the cart for the user
            $check_query = $conn->prepare("SELECT * FROM addtocart WHERE prdID = ? AND usrID = ?");
            $check_query->execute([$product_id, $user_id]);
            $existing_product = $check_query->fetch();

            if ($existing_product) {
                // If the product already exists, update the quantity
                $update_query = $conn->prepare("UPDATE addtocart SET quantity = quantity + 1 WHERE prdID = ? AND usrID = ?");
                $update_query->execute([$product_id, $user_id]);
            } else {
                // If the product doesn't exist, insert a new record
                $insert_query = $conn->prepare("INSERT INTO addtocart (prdID, usrID, image, name, price, quantity) VALUES (?, ?, ?, ?, ?, ?)");
                $insert_query->execute([$product_id, $user_id, $product_image, $product_name, $product_price, $quantity]);
            }

            echo 'Product added to cart successfully'; // Send a response back to the client
        } catch (PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    } else {
        // Handle invalid requests (if needed)
        echo 'Invalid request';
    }
?>