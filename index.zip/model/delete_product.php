<?php

    include '../config/config.php';
    include 'conn.php';

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['product_image'])) {
        $product_image = $_GET["product_image"];
        
        // Xóa sản phẩm từ CSDL
        $stmt = $conn->prepare("DELETE FROM product WHERE image = :product_image");
        $stmt->bindParam(':product_image', $product_image, PDO::PARAM_STR);
    
        if ($stmt->execute()) {
            echo '<script>
                    alert("Product Delete Success.");
                    window.location.href = "../admin.php";
                </script>';
            exit();
        } else {
            $errorInfo = $stmt->errorInfo();
            echo "Lỗi: " . $errorInfo[2]; // In thông báo lỗi
        }
    }