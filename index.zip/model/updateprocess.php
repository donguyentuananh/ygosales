<?php
    require '../config/config.php';
    include 'conn.php';

    // if (isset($_POST['update_submit'])) {
    //     // Retrieve the values from the form
    //     $update_name = ($_POST['update_name'] !== '') ? $_POST['update_name'] : null;
    //     $update_price = ($_POST['update_price'] !== '') ? $_POST['update_price'] : null;
    //     $current_image = $_POST['current_image'];
    
    //     // Check if a new image is uploaded
    //     if ($_FILES['update_img']['error'] === UPLOAD_ERR_OK) {
    //         $image_name = $_FILES['update_img']['name'];
    //         $image_path = '../asset/image/' . $image_name;
    
    //         // Move the uploaded file to the destination
    //         move_uploaded_file($_FILES['update_img']['tmp_name'], $image_path);
    //     } else {
    //         // If no new image is uploaded, keep the current image name
    //         $image_name = $current_image;
    //     }
    
    //     // Prepare the database update query
    //     $update_query = "UPDATE product SET";
    //     $update_params = array();
    
    //     if ($update_name !== null) {
    //         $update_query .= " name = :update_name,";
    //         $update_params[':update_name'] = $update_name;
    //     }
    
    //     if ($update_price !== null) {
    //         $update_query .= " price = :update_price,";
    //         $update_params[':update_price'] = $update_price;
    //     }
    
    //     $update_query .= " image = :image_name WHERE image = :current_image";
    //     $update_params[':image_name'] = $image_name;
    //     $update_params[':current_image'] = $current_image;
    
    //     // Remove the trailing comma if no fields were updated
    //     $update_query = rtrim($update_query, ',');
    
    //     // Perform the database update
    //     $update_stmt = $conn->prepare($update_query);
    
    //     foreach ($update_params as $param => &$value) {
    //         $update_stmt->bindParam($param, $value);
    //     }
    
    //     if ($update_stmt->execute()) {
    //         echo "Product updated successfully.";
    //         // You can redirect or perform other actions after the update.
    //     } else {
    //         echo "Error updating product.";
    //     }
    // }

    if (isset($_POST['update_submit'])) {
        // Retrieve the values from the form
        $update_name = ($_POST['update_name'] !== '') ? $_POST['update_name'] : null;
        $update_price = ($_POST['update_price'] !== '') ? $_POST['update_price'] : null;
        $update_quantity = ($_POST['update_quantity'] !== '') ? $_POST['update_quantity'] : null;
        $current_image = $_POST['current_image'];
        $currentID = $_POST['current_id'];
    
        // Check if a new image is uploaded
        if ($_FILES['update_img']['error'] === UPLOAD_ERR_OK) {
            $image_name = $_FILES['update_img']['name'];
            $image_path = '../asset/image/' . $image_name;
    
            // Move the uploaded file to the destination
            move_uploaded_file($_FILES['update_img']['tmp_name'], $image_path);
    
            // Remove file extension
            $image_name_without_extension = pathinfo($image_path, PATHINFO_FILENAME);
            $image_name = $image_name_without_extension;
        } else {
            // If no new image is uploaded, keep the current image name
            $image_name = $current_image;
        }
    
        // Prepare the database update query
        $update_query = "UPDATE product SET";
        $update_params = array();
    
        if ($update_name !== null) {
            $update_query .= " name = :update_name,";
            $update_params[':update_name'] = $update_name;
        }
    
        if ($update_price !== null) {
            $update_query .= " price = :update_price,";
            $update_params[':update_price'] = $update_price;
        }

        if ($update_quantity !== null) {
            $update_query .= " quantity = :update_quantity,";
            $update_params[':update_quantity'] = $update_quantity;
        }
    
        $update_query .= " image = :image_name WHERE image = :current_image";
        $update_params[':image_name'] = $image_name;
        $update_params[':current_image'] = $current_image;
    
        // Remove the trailing comma if no fields were updated
        $update_query = rtrim($update_query, ',');
    
        // Perform the database update
        $update_stmt = $conn->prepare($update_query);
    
        foreach ($update_params as $param => &$value) {
            $update_stmt->bindParam($param, $value);
        }

        // $currentPage = isset($_GET['pagi']) ? $_GET['pagi'] : 1;
    
        // if ($update_stmt->execute()) {
        //     // Product updated successfully
        //     echo '<script>alert("Product updated successfully.");';
        //     echo "window.location.href = '../view/addel.php?pagi=$currentPage';</script>";
        // } else {
        //     // Error updating product
        //     echo '<script>alert("Error updating product.");';
        //     echo "window.location.href = '../view/addel.php?pagi=$currentPage';</script>";
        // }

        if ($update_stmt->execute()) {
            // Product updated successfully
            echo '<script>alert("Product updated successfully.");';
            echo "window.location.href = '../admin.php?page=updateproduct&id=$currentID';</script>";
        } else {
            // Error updating product
            echo '<script>alert("Error updating product.");';
            echo "window.location.href = '../admin.php?page=updateproduct&id=$currentID';</script>";
        }
    }
