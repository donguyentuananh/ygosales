<?php
    session_start();

    include '../config/config.php';
    include 'conn.php'; // Include your database configuration

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $prd_id = $_POST['prd_id'];
        $user_id = $_SESSION['user_id'];
        $image = $_POST['image'];
        $name = $_POST['name'];
        $price = $_POST['price'];
        $current_quantity = $_POST['current_quantity'];
        $quantity = $_POST['quantity'];

        // Validate and sanitize data as needed
        if ($quantity < 1) {
            // Quantity is less than 1, do not proceed with the insert
            echo '<script>alert("Quantity must be bigger than 0.");';
            echo "window.location.href = '../index.php?page=detailproduct&id=$prd_id';</script>";
            exit();
        }

        // Check if the quantity is greater than the current quantity in stock
        if ($quantity > $current) {
            // Quantity is greater than the current quantity in stock
            echo '<script>alert("Sản phẩm trong kho không đủ.");';
            echo "window.location.href = '../index.php?page=detailproduct&id=$prd_id';</script>";
            exit();
        }
    
        // Validate and sanitize data as needed
    
        try {
    
            // Check if a record with the given user ID and product ID already exists
            $checkStmt = $conn->prepare("SELECT * FROM addtocart WHERE prdID = ? AND usrID = ?");
            $checkStmt->execute([$prd_id, $user_id]);
            $existingRecord = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if ($existingRecord) {
                // If the record exists, update the quantity
                $updateStmt = $conn->prepare("UPDATE addtocart SET quantity = quantity + ? WHERE prdID = ? AND usrID = ?");
                $updateStmt->execute([$quantity, $prd_id, $user_id]);
            } else {
                // If the record doesn't exist, insert a new record
                $insertStmt = $conn->prepare("INSERT INTO addtocart (prdID, usrID, image, name, price, quantity) VALUES (?, ?, ?, ?, ?, ?)");
                $insertStmt->execute([$prd_id, $user_id, $image, $name, $price, $quantity]);
            }
    
            // Redirect or perform any other action after successful insertion
            echo "<script>window.location.href = '../index.php?page=detailproduct&id=$prd_id'</script>;";
            exit();
        }
        catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        } 
        finally {
            $conn = null;
        }
    }
?>
