<?php
    require '../config/config.php';
    require 'conn.php';

    try {

        // Get the selected cart item IDs from the AJAX request
        $cartItemIDs = $_POST['cartItemIDs'];

        // Prepare and execute a query to delete selected items
        $stmt = $conn->prepare("DELETE FROM addtocart WHERE cartID IN (" . implode(',', $cartItemIDs) . ")");
        $stmt->execute();

        // Return a success message or any response you need
        echo "Items deleted successfully";
    } catch (PDOException $e) {
        // Handle database errors
        echo "Error: " . $e->getMessage();
    }

    $conn = null;
?>