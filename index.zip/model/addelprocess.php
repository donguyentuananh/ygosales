<?php
    
    // require '../config/config.php';
    // include 'conn.php';

    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //     $add_name = $_POST["add_name"];
    //     $add_price = $_POST["add_price"];
    //     $add_img_name = pathinfo($_FILES["add_img"]["name"], PATHINFO_FILENAME); // Lấy tên file không có phần mở rộng

    
    //     $target_dir = "../asset/image/"; // Thư mục để lưu trữ hình ảnh
    //     $target_file = $target_dir . basename($_FILES["add_img"]["name"]);
    
    //     // Di chuyển hình ảnh vào thư mục lưu trữ
    //     move_uploaded_file($_FILES["add_img"]["tmp_name"], $target_file);
    
    //     $sql = "INSERT INTO product (image, name, price) VALUES ('$add_img_name', '$add_name', '$add_price')";
    
    //     if ($conn->query($sql) === TRUE) {
    //         header ('location: ../view/addel.php');
    //     } else {
    //         echo "Lỗi: " . $sql . "<br>" . $conn->error;
    //     }
    
    // }

    require '../config/config.php';
    include 'conn.php';

    // if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //     $add_name = $_POST["add_name"];
    //     $add_price = $_POST["add_price"];
    //     $add_img_name = pathinfo($_FILES["add_img"]["name"], PATHINFO_FILENAME); // Lấy tên file không có phần mở rộng

    //     $target_dir = "../asset/image/"; // Thư mục để lưu trữ hình ảnh
    //     $target_file = $target_dir . basename($_FILES["add_img"]["name"]);

    //     // Di chuyển hình ảnh vào thư mục lưu trữ
    //     move_uploaded_file($_FILES["add_img"]["tmp_name"], $target_file);

    //     // Sử dụng PDO để kết nối CSDL
    //     try {

    //         // Sử dụng prepared statement để chèn dữ liệu
    //         $stmt = $conn->prepare("INSERT INTO product (image, name, price) VALUES (:add_img_name, :add_name, :add_price)");
    //         $stmt->bindParam(':add_img_name', $add_img_name);
    //         $stmt->bindParam(':add_name', $add_name);
    //         $stmt->bindParam(':add_price', $add_price);

    //         $stmt->execute();

    //         header('location: ../view/addel.php');
    //     } catch (PDOException $e) {
    //         header('location: ../view/addel.php?error=1');
    //         exit();
    //     }

    //     $conn = null;
    // }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $add_name = $_POST["add_name"];
        $add_price = $_POST["add_price"];
        $add_quantity = $_POST["add_quantity"];
        $add_img_name = pathinfo($_FILES["add_img"]["name"], PATHINFO_FILENAME);
    
        $target_dir = "../asset/image/";
        $target_file = $target_dir . basename($_FILES["add_img"]["name"]);
    
        // Check if the image with the same name exists in the database
        $check_query = "SELECT COUNT(*) FROM product WHERE image = :add_img_name";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bindParam(':add_img_name', $add_img_name);
        $check_stmt->execute();
    
        $image_exists = $check_stmt->fetchColumn();
    
        if ($image_exists > 0) {
            // Image with the same name already exists
            echo '<script>alert("Product Insert Fail.");';
            echo "window.location.href = '../admin.php?page=addproduct';</script>"; // You can customize the error code
            exit();
        }
    
        // Move the uploaded file to the destination
        move_uploaded_file($_FILES["add_img"]["tmp_name"], $target_file);
    
        try {
            // Use prepared statement to insert data
            $stmt = $conn->prepare("INSERT INTO product (image, name, price, quantity) VALUES (:add_img_name, :add_name, :add_price, :add_quantity)");
            $stmt->bindParam(':add_img_name', $add_img_name);
            $stmt->bindParam(':add_name', $add_name);
            $stmt->bindParam(':add_price', $add_price);
            $stmt->bindParam(':add_quantity', $add_quantity);
    
            $stmt->execute();
            
            echo '<script>
                    alert("Product Insert Success.");
                    window.location.href = "../admin.php?page=addproduct";
                </script>';
        } catch (PDOException $e) {
            header('location: ../admin.php?page=addproduct?error=1');
            exit();
        }
    
        $conn = null;
    }




