<?php

    include '../config/config.php';
    include 'conn.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Kiểm tra xem email hoặc username đã tồn tại chưa
        $email = $_POST['email'];
        $username = $_POST['username'];

        $stmt = $conn->prepare("SELECT * FROM user WHERE email = ? OR username = ?");
        $stmt->bindParam(1, $email);
        $stmt->bindParam(2, $username);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            echo "<script>
                    alert('Email hoặc username đã tồn tại.');
                    window.location.href='../view/register.php';
                </script>";
        } else {
            // Tiếp tục xử lý đăng ký khi không có email hoặc username trùng lặp
            $name = $_POST['name'];
            $pwd = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $cfm_pwd = $_POST['cfm-password'];
            $role = "user";
            $status = "unlock";

            $stmt = $conn->prepare("INSERT INTO user (name, username, email, password, confirm, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bindParam(1, $name);
            $stmt->bindParam(2, $username);
            $stmt->bindParam(3, $email);
            $stmt->bindParam(4, $pwd);
            $stmt->bindParam(5, $cfm_pwd);
            $stmt->bindParam(6, $role);
            $stmt->bindParam(7, $status);
            $stmt->execute();

            if ($stmt) {
                echo "<script>
                    alert('Đăng kí thành công.');
                    window.location.href='../view/login.php';
                </script>";
            }
        }
    }else {
        echo "<script>
                alert('Vui lòng nhập đủ thông tin.');
                window.location.href='../view/register.php';
            </script>";
    }

    $conn = null;
?>