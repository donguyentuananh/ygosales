<?php
    
    require '../config/config.php';
    include 'conn.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve data from the POST request
        $cartIds = $_POST['cartIds'];

        // Perform database deletions
        try {
            $stmt = $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
            foreach ($cartIds as $cartId) {
                $stmt->execute([$cartId]);
            }

            // Output success message (you can customize this based on your needs)
            echo "Products deleted successfully!";
        } catch (PDOException $e) {
            // Handle database errors (you can log or output an error message)
            echo "Error: " . $e->getMessage();
        } finally {
            // Close the database connection
            $conn = null;
        }
    } else {
        // Handle invalid request method (e.g., someone accessing the script directly)
        http_response_code(400); // Bad Request
        echo "Invalid request method";
    }
?>
