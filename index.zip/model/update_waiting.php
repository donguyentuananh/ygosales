<?php

    require '../config/config.php';
    include 'conn.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $cartIds = $_POST["cartIds"];
        $selectedStatus = $_POST["selectedStatus"];
    
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("UPDATE cart SET waiting = ? WHERE cart_id IN (" . implode(",", array_fill(0, count($cartIds), "?")) . ")");
        $stmt->bindValue(1, $selectedStatus);
    
        foreach ($cartIds as $index => $cartId) {
            $stmt->bindValue($index + 2, $cartId);
        }
    
        $stmt->execute();
    
        // Return a response if needed
        echo "Update successful!";
    }
    
?>