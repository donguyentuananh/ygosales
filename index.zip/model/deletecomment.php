<?php
    session_start();

    include '../config/config.php';  
    include 'conn.php';             

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_id'])) {
        $commentId = $_POST['comment_id'];

        // Validate and sanitize data as needed

        try {
            // Prepare and execute the SQL query to delete the comment
            $deleteStmt = $conn->prepare("DELETE FROM comment WHERE cmt_id = ?");
            $deleteStmt->execute([$commentId]);

            // Return success message (optional)
            echo "Comment deleted successfully!";
        } catch (PDOException $e) {
            // Handle the error
            echo "Error: " . $e->getMessage();
        } finally {
            $conn = null;
        }
    }
?>