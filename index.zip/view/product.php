<!-- <div class="space"></div> -->

    <div class="body">
      <div class="list-prd">
        <button>DANH MỤC</button>
        <div></div>
        <label for="">Bài lẻ Maze - Memories</label>
        <div></div>
        <label for="">Bài lẻ Amde - Amazing</label>
        <div></div>
        <label for="">Bài lẻ BRCL Crystal Revenge</label>
        <div></div>
        <label for="">Bài lẻ SR13 - Dark World</label>
        <div></div>
        <label for="">Bài lẻ SDCB - Crystal Beasts</label>
      </div>
    <div class="show-prd">

        <label for="searchTerm">KẾT QUẢ TÌM KIẾM</label>
        <div id="results"></div>
        <!-- <script src="asset/javascript/addToSearchCart.js"></script> -->
        

        <label for="">SẢN PHẨM NGUYÊN HỘP</label>
        <div class="prd-box">

                <?php
                    if (isset($_REQUEST['pagi'])){
                        $offset = ($_REQUEST['pagi']-1)*8;
                    } else {
                        $offset = 0;
                    }
                    
                    // Retrieve user_id from the session
                    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

                    $stmt = $conn->query("SELECT * FROM product ORDER BY prd_id DESC LIMIT $offset,8");
                    
                    while ($row = $stmt->fetch()) {
                        echo '                
                        <div class="card-box">
                            <form class="add-to-cart-form">
                                <input type="hidden" name="user_id" value="' . $user_id . '">
                                <input type="hidden" name="product_id" value="' . $row['prd_id'] . '">
                                <input type="hidden" name="product_name" value="' . $row['name'] . '">
                                <input type="hidden" name="product_price" value="' . $row['price'] . '">
                                <input type="hidden" name="product_image" value="' . $row['image'] . '">
                                <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">
                                    <img src="asset/image/' . $row['image'] . '.jpg" alt="Hộp thẻ bài Yugioh">
                                </a>
                                <span>
                                    <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                                </span>
                                <label>
                                    <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['price'] . ' VND</a>
                                </label>
                                <button type="button" class="add-to-cart">+</button>
                            </form>
                        </div>';
                    }
                ?>

                <!-- Include jQuery -->
                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

                <!-- JavaScript for Add-to-Cart functionality -->
                <script>
                    $(document).ready(function() {
                        $('.add-to-cart').on('click', function() {
                            var form = $(this).closest('.add-to-cart-form');
                            var user_id = form.find('input[name="user_id"]').val();
                            var product_id = form.find('input[name="product_id"]').val();
                            var product_name = form.find('input[name="product_name"]').val();
                            var product_price = form.find('input[name="product_price"]').val();
                            var product_image = form.find('input[name="product_image"]').val();

                            // Send an AJAX request to the server to insert the product into the cart
                            $.ajax({
                                url: '../model/addtocartprocess.php', // Adjust the path based on your project structure
                                method: 'POST',
                                data: {
                                    user_id: user_id,
                                    product_id: product_id,
                                    product_name: product_name,
                                    product_price: product_price,
                                    product_image: product_image
                                },
                                success: function(response) {
                                    // Handle the response (if needed)
                                    console.log(response);
                                    location.reload();

                                },
                                error: function(error) {
                                    // Handle errors (if needed)
                                    console.error(error);
                                    location.reload();

                                    // Show alert when successfully added to the cart
                                    alert('Thêm vào giỏ hàng không thành công');
                                },
                                complete: function() {
                                    // After the request is complete, update the cart items display
                                    updateCartItems();
                                }
                            });
                        });

                        // function updateCartItems() {
                        //     // Send an AJAX request to retrieve cart items and update the display
                        //     $.ajax({
                        //         url: '../model/cart_operation.php', // Adjust the path based on your project structure
                        //         method: 'GET',
                        //         data: { action: 'get' },
                        //         success: function(response) {
                        //             // Update the cart items display in the .cart-items div
                        //             $('.cart-items').html(response);
                        //         },
                        //         error: function(error) {
                        //             // Handle errors (if needed)
                        //             console.error(error);
                        //         }
                        //     });
                        // }
                    });
                </script>

                <?php
                    // if (isset($_REQUEST['pagi'])){
                    //     $offset = ($_REQUEST['pagi']-1)*8;
                    // } else {
                    //     $offset = 0;
                    // }
                    
                    // $stmt = $conn->query("SELECT * FROM product ORDER BY prd_id DESC LIMIT $offset,8");
                    
                    // while ($row = $stmt->fetch()) {
                    //     echo '                
                    //     <div class="card-box">
                    //         <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">
                    //             <img src="asset/image/' . $row['image'] . '.jpg" alt="Hộp thẻ bài Yugioh">
                    //         </a>
                    //         <span>
                    //             <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                    //         </span>
                    //         <label>
                    //             <a href="index.php?page=detailproduct&id=' . $row['prd_id'] . '">' . $row['price'] . ' VND</a>
                    //         </label>
                    //         <button class="add-to-cart">+</button>
                    //     </div>';
                    // }
                ?>
        </div>

        <div class="divide-page">
                <?php
                    // $rows = $conn -> query("SELECT count(*) FROM product") -> fetchColumn();
                    // $total_pages = ceil($rows / 8);
                    // for($i = 1; $i <= $total_pages; $i++){
                    //     echo "<a href='index.php?pagi=$i'>$i</a>";
                    // }

                    $currentPage = isset($_GET['pagi']) ? $_GET['pagi'] : 1;
                    $rows = $conn->query("SELECT count(*) FROM product")->fetchColumn();
                    $total_pages = ceil($rows / 10);

                    // Nút "Lùi một trang"
                    if ($currentPage > 1) {
                        echo "<a href='index.php?pagi=" . ($currentPage - 1) . "'><i class='bx bx-chevron-left'></i></a>";
                    }

                    for ($i = 1; $i <= $total_pages; $i++) {
                        echo "<a href='index.php?pagi=$i'>$i</a>";
                    }

                    // Nút "Tiến một trang"
                    if ($currentPage < $total_pages) {
                        echo "<a href='index.php?pagi=" . ($currentPage + 1) . "'><i class='bx bx-chevron-right' ></i></a>";
                    }
                ?>
        </div>

    </div>

        <!-- <script src="asset/javascript/addToCart.js"></script> -->
        
    </div>