    <div class="manage-user-container">

        <h2>User Manager</h2>

        <div class="search-container">
            <button id="searchButton"><i class='bx bx-search'></i></button>
            <input type="text" id="searchTerm" placeholder="Thanh tìm kiếm...">
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <script src="../asset/javascript/userSearch.js"></script>

        <div class="user-title" align="center">
            <span>UserID</span>
            <span>Name</span>
            <span>UserName</span>
            <span>Email</span>
            <span>Password</span>
            <span>Role</span>
            <span>Status</span>
            <span>Manage</span>
        </div>
            <?php
                if (isset($_REQUEST['pagi'])){
                    $offset = ($_REQUEST['pagi']-1)*10;
                }else $offset = 0;
                    $stmt = $conn -> query("SELECT * FROM user limit $offset,10");
                while($row = $stmt -> fetch()){
                    echo '                
                    <div class="user-content" align="center">
                        <span>' . $row['user_id'] . '</span>
                        <span>' . $row['name'] . '</span>
                        <span>' . $row['username'] . '</span>
                        <span>' . $row['email'] . '</span>
                        <span>' . $row['confirm'] . '</span>
                        <span>' . $row['role'] . '</span>
                        <span>' . $row['status'] . '</span>
                        <span>
                            <a href="admin.php?page=updateuser&id=' . $row['user_id'] . '">Edit</a>
                        </span>
                    </div>';    
                    }
                ?>

                <label for="searchTerm" class="laBel">KẾT QUẢ TÌM KIẾM</label>
                <div id="results" class="card-box-full"></div>

                <div class="divide-page">
                    <?php
                        // $rows = $conn -> query("SELECT count(*) FROM product") -> fetchColumn();
                        // $total_pages = ceil($rows / 10);
                        // for($i = 1; $i <= $total_pages; $i++){
                        //     echo "<a href='addel.php?pagi=$i'>$i</a>";
                        // }

                        $currentPage = isset($_GET['pagi']) ? $_GET['pagi'] : 1;
                        $rows = $conn->query("SELECT count(*) FROM user")->fetchColumn();
                        $total_pages = ceil($rows / 10);

                        // Nút "Lùi một trang"
                        if ($currentPage > 1) {
                            echo "<a href='admin.php?pagi=" . ($currentPage - 1) . "'><i class='bx bx-chevron-left'></i></a>";
                        }

                        for ($i = 1; $i <= $total_pages; $i++) {
                            echo "<a href='admin.php?pagi=$i'>$i</a>";
                        }

                        // Nút "Tiến một trang"
                        if ($currentPage < $total_pages) {
                            echo "<a href='admin.php?pagi=" . ($currentPage + 1) . "'><i class='bx bx-chevron-right' ></i></a>";
                        }
                    ?>
                </div>
    </div>
</div>