<div class="payment-container">
    <?php
        if (!isset($_SESSION['username'])) { ?>
            <div>QUÝ KHÁCH CHƯA <a href="index.php?page=login">ĐĂNG NHẬP</a></div>
    <?php } else { ?> 

        <div class="payment-address">
            <h4>Thông tin giao hàng</h4>
            <form action="" id="paymentForm">

            <?php

                // Retrieve user ID from the session
                $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

                if ($user_id) {
                    // Check if user exists in 'userinfo' table
                    $stmt = $conn->prepare("SELECT * FROM userinfor WHERE usrID = ?");
                    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
                    $stmt->execute();

                    if ($stmt->rowCount() > 0) {
                        // User exists, fetch and display the data
                        $userInfor = $stmt->fetch();
                        ?>
                        <div>
                            <label for="address">Địa chỉ:</label>
                            <input type="text" name="address" value="<?= $userInfor['address'] ?>">
                        </div>
                        <div>
                            <label for="phone_number">Số điện thoại:</label>
                            <input type="text" name="phone_number" value="0<?= $userInfor['phone_number'] ?>">
                        </div>
                <?php
                    } else {
                        // User doesn't exist in 'userinfo' table, show empty fields
                ?>
                        <div>
                            <label for="address">Địa chỉ:</label>
                            <input type="text" name="address">
                        </div>
                        <div>
                            <label for="phone_number">Số điện thoại:</label>
                            <input type="text" name="phone_number">
                        </div>
                <?php
                        }
                    } else {
                        // User is not logged in, show empty fields
                ?>
                    <div>
                        <label for="address">Địa chỉ:</label>
                        <input type="text" name="address">
                    </div>
                    <div>
                        <label for="phone_number">Số điện thoại:</label>
                        <input type="text" name="phone_number">
                    </div>
                    <?php
                }

            ?>

                <div>
                    <label for="payment_method">Phương thức thanh toán:</label>
                    <select name="payment_method" id="payment_method">
                        <option value="banking">Chuyển khoản</option>
                        <option value="cod">Thanh toán khi nhận hàng</option>
                    </select>
                </div>
                <div class="note-box">
                    <label for="note">Ghi chú:</label>
                    <textarea name="note" id="note" cols="30" rows="15"></textarea>
                </div>
            </form>
        </div>

        <div class="payment-cart">
            <h4>Giỏ hàng</h4>
            <div class="payment-cart-product">
                <div class="title-cart-product" align="center">
                    <h5>Check box</h5>
                    <h5>Hình ảnh</h5>
                    <h5>Tên sản phẩm</h5>
                    <h5>Số lượng</h5>
                    <h5>Giá sản phẩm</h5>
                    <h5>Thành tiền</h5>
                </div>
                <?php

                    // Retrieve user ID from the session
                    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

                    // Prepare and execute a query to get cart items for the user
                    $stmt = $conn->prepare("SELECT * FROM addtocart WHERE usrID = ?");
                    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
                    $stmt->execute();

                    // Initialize total sum
                    $totalSum = 0;

                    // Display cart items
                    if ($stmt->rowCount() > 0) {
                        // Initialize an array to store total prices for each item
                        $_SESSION['total_prices'] = [];

                        while ($row = $stmt->fetch()) {
                            // Calculate total price for each item
                            $total_price = $row['quantity'] * $row['price'];
                            $totalSum += $total_price + 30;

                            // Display cart item
                            ?>
                                <div class="content-cart-product" align="center" data-prd-id="<?= $row['cartID'] ?>">
                                    <input type="checkbox" class="cart-item-checkbox" data-cart-id="<?= $row['cartID'] ?>">
                                    <img src="../asset/image/<?= $row['image'] ?>.jpg" alt="">
                                    <span><?= $row['name'] ?></span>
                                    <div>
                                        <input type="number" value="<?= $row['quantity'] ?>"
                                            data-cart-id="<?= $row['cartID'] ?>"
                                            class="quantity-input">
                                    </div>
                                    <label for=""><?= $row['price'] ?></label>
                                    <p><?= number_format($total_price, 0, ',', '.') ?>.000</p>
                                </div>
                            <?php
                        }

                        // Display the total payment after processing all items
                        ?>
                            <div class="footer-payment-cart">
                                <div class="select-all-checkbox">
                                    <input type="checkbox" id="selectAllCheckbox">
                                    <label for="selectAllCheckbox">Chọn tất cả</label>
                                    <button id="deleteButton">Xóa</button>
                                </div>
                                <div class="total-payment">
                                    <label for="">Phí vận chuyển: 30.000 VND</label> <br><br>
                                    <span id="totalSumDisplay">Tổng thanh toán: 0 VND</span>
                                </div>
                                <button type="button" id="submitPayment" onclick="submitPayment()">Thanh toán</button>
                            </div>

                            <script src="../asset/javascript/paymentCartFunction.js"></script>

                            <script src="../asset/javascript/paymentFunction.js"></script>

                            <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

                        <?php
                    } else {
                        // Display a message if the cart is empty
                        ?>
                            <div class="empty-cart-payment">
                                Không có sản phẩm trong giỏ hàng, quay về <a href="index.php">trang chủ</a> để mua hàng nào.
                            </div>
                        <?php
                    }
                    ?>

                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

                <script>
                    
                    $(document).ready(function () {
                        // Listen for change event on quantity inputs
                        $('.quantity-input').on('change', function () {
                            // Get the new quantity value
                            var newQuantity = $(this).val();
                            // Get the cart ID from the data attribute
                            var cartId = $(this).data('cart-id');

                            // Send an AJAX request to handle both update and remove functionality
                            $.ajax({
                                type: 'POST',
                                url: '../model/updatequantity.php',
                                data: { cart_id: cartId, new_quantity: newQuantity },
                                success: function (response) {
                                    // Handle success (if needed)
                                    console.log(response);

                                    // Optionally, you can update the cart UI after successful update
                                    // For example, update the total price or reflect the new quantity without reloading the entire page
                                },
                                error: function (error) {
                                    // Handle errors (if needed)
                                    console.error(error);

                                    // Display an error message to the user or log the error for debugging
                                },
                                complete: function () {
                                    // Whether the request succeeds or fails, you can choose to reload the page here if needed
                                    location.reload();
                                }
                            });
                        });
                    });

                </script>

            </div>
            
        </div>

    <?php } ?>

</div>