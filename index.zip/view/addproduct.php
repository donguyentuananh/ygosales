<div class="add-product">
            <h2>Thêm Sản Phẩm</h2>
                <form action="../model/addelprocess.php" method="post" enctype="multipart/form-data">
                    <div>
                        <label for="name">Tên Sản Phẩm:</label>
                        <input type="text" id="name" name="add_name" required>
                    </div>
                    <div>
                        <label for="price">Giá:</label>
                        <input type="text" id="price" name="add_price" required>
                    </div>
                    <div>
                        <label for="quantity">Số Lượng:</label>
                        <input type="text" id="quantity" name="add_quantity" required>
                    </div>
                    <div>   
                        <label for="img">Hình ảnh:</label>
                        <input type="file" id="img" name="add_img" required>
                    </div>
                    <button type="submit">Thêm</button>
                </form>
        </div>
    </div>
