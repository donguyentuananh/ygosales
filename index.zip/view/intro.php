<section id="introduction" align="center">
            <h2>Giới thiệu về Yugioh</h2>
            <p class="intro-content">"YGO" chuyển hướng đến đây. Đối với sân bay ở Canada có mã IATA YGO, xem Sân bay Gods Lake Narrows .
                Bài này viết về bộ truyện tranh gốc và nhượng quyền thương mại nói chung. Đối với các mục đích sử dụng khác, xem Yu-Gi-Oh! (định hướng) .
                Yu-Gi-Oh! <br>

                <img src="../asset/image/download.jpg" alt="" width="50%"> <br>

                Bìa tập tankōbon đầu tiên , có Yugi Mutou
                遊☆戯☆王
                (Yū-Gi-Ō!)
                thể loại	
                Cuộc phiêu lưu [1]
                Khoa học giả tưởng [1]
                Truyện
                Được viết bởi	Kazuki Takahashi
                Xuất bản bởi	Shueisha
                nhà xuất bản tiếng Anh	
                NA : Viz Media
                dấu ấn	truyện tranh nhảy
                Tạp chí	Nhảy Shōnen hàng tuần
                tạp chí tiếng anh	
                NA : nhảy Shonen
                Nhân khẩu học	Shonen
                Chạy ban đầu	17 tháng 9 năm 1996 – 8 tháng 3 năm 2004
                Tập	38 ( Danh sách các tập )
                Phim truyền hình anime
                Đạo diễn bởi	Hiroyuki Kakudo
                Được viết bởi	Toshiki Inoue
                Âm nhạc của	BMF
                Phòng thu	Hoạt Hình Toei
                Mạng gốc	truyền hình Asahi
                Chạy ban đầu	4 tháng 4 năm 1998 – 10 tháng 10 năm 1998
                tập phim	27 ( Danh sách các tập phim )
                phim hoạt hình
                Đạo diễn bởi	Junji Shimizu
                Được viết bởi	Yasuko Kobayashi
                Âm nhạc của	BMF
                Phòng thu	Hoạt Hình Toei
                Phát hành	Ngày 6 tháng 3 năm 1999
                Thời gian chạy	30 phút
                Cuốn tiểu thuyết
                Được viết bởi	Katsuhiko Chiba
                Minh họa bởi	Kazuki Takahashi
                Xuất bản bởi	Shueisha
                dấu ấn	Nhảy J-Books
                Nhân khẩu học	Nam giới
                Được phát hành	Ngày 3 tháng 9 năm 1999
                Phim truyền hình anime
                Yu-Gi-Oh! Đấu tay đôi với quái vật (2000–04)
                phim hoạt hình
                Yu-Gi-Oh! Phim: Kim tự tháp ánh sáng
                Yu-Gi-Oh!: Mối ràng buộc vượt thời gian
                Yu-Gi-Oh!: Mặt tối của các chiều không gian
                loạt khác
                Danh sách tất cả Yu-Gi-Oh! loạt
                Yu-Gi-Oh! R
                Phương tiện truyền thông khác
                Trò chơi điện tử
                Trò chơi giao dịch thẻ bài
                biểu tượng Cổng thông tin anime và manga
                Yu-Gi-Oh! ( Tiếng Nhật :遊☆戯☆王, Hepburn : Yū-Gi-Ō! , lit. "Game King") là một bộ truyện tranh Nhật Bản được viết và minh họa bởi Kazuki Takahashi . Nó được đăng nhiều kỳ trên tạp chí Weekly Shōnen Jump của Shueisha từ tháng 9 năm 1996 đến tháng 3 năm 2004. Cốt truyện kể về câu chuyện của một cậu bé tên Yugi Mutou , người giải được Câu đố Thiên niên kỷ cổ đại. Yugi đánh thức bản ngã hoặc linh hồn cờ bạc trong cơ thể mình để giải quyết xung đột bằng nhiều trò chơi khác nhau.
                
                Bộ truyện tranh này đã tạo ra một thương hiệu truyền thông bao gồm nhiều bộ truyện tranh và anime phụ , một trò chơi đánh bài và nhiều trò chơi điện tử. Hầu hết các hóa thân này đều liên quan đến trò chơi giao dịch thẻ bài hư cấu được gọi là Duel Monsters , trong đó mỗi người chơi sử dụng các lá bài để "đấu tay đôi" với nhau trong một trận chiến giả giữa các "quái vật" tưởng tượng, tạo cơ sở cho Yu-Gi-Oh! ngoài đời thực! Trading Card Game gắn liền với nhau. Manga đã được chuyển thể thành hai bộ anime; bản chuyển thể anime đầu tiên do Toei Animation sản xuất , phát sóng từ tháng 4 đến tháng 10 năm 1998, trong khi bản chuyển thể thứ hai do NAS sản xuất và hoạt hình bởi Studio Gallop có tựa đề Yu-Gi-Oh! Duel Monsters , phát sóng từ tháng 4 năm 2000 đến tháng 9 năm 2004. Yu-Gi-Oh! kể từ đó đã trở thành một trong những thương hiệu truyền thông có doanh thu cao nhất mọi thời đại.</p>
        </section>