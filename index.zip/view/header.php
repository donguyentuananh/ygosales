<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>M2 Duel Store - YGO</title>
    <link rel="stylesheet" href="../asset/style.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
</head>
<body>
    <header>
        <div class="box1">
            <div class="ani10th">
                <img src="https://m2duelstore.com/image/cache/catalog/HONG%20DUC/2022.03/Logo%20web-192x85.png" alt="">
            </div>
            <a href="index.php" style="color: rgb(170, 132, 82);">TRANG CHỦ</a> <label>|</label>
            <a href="#">TIN TỨC</a> <label>|</label> 
            <a href="index.php?page=intro">GIỚI THIỆU</a> <label>|</label> 
            <div class="dropdown">
                <script>
                        document.addEventListener("DOMContentLoaded", function() {
                        var dropdown = document.querySelector(".dropdown");
                        var dropbtn = document.querySelector(".dropbtn");
                        
                        dropbtn.addEventListener("click", function() {
                        dropdown.classList.toggle("active");
                        });
                    });
                </script>
                <button class="dropbtn">SẢN PHẨM V</button>
                <div class="dropdown-content">
                  <a href="#">Nguyên Hộp YUGIOH</a>
                  <a href="#">Bài lẻ YUGIOH</a>
                  <a href="#">Bài lẻ POKEMON</a>
                  <a href="#">Bài lẻ DRAGON BALL</a>
                  <a href="#">Cửa Hàng Bài Thủ</a>
                </div>
              </div> <label>|</label>
            <a href="#">KHUYẾN MÃI</a> <label>|</label>
            <a href="#">M2 CHANEL</a> <label>|</label>
            <a href="#">LIÊN LẠC</a> <label>|</label>
            <?php
                if (isset($_SESSION['username']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
                    echo '<a href="index.php?page=admin">' . $_SESSION['username'] . '</a>';
                } else if (isset($_SESSION['username']) && isset($_SESSION['role']) && $_SESSION['role'] == 'user') {
                    echo  '<a href="index.php?page=user">' . $_SESSION['username'] . '</a>';
                }
                
            ?>
        </div>
        <div class="box2">
            <div class="log-pay">

                <?php if (!isset($_SESSION['username'])) { ?>
                    <a href="index.php?page=login">ĐĂNG NHẬP</a>
                <?php } else { ?>   
                    <a href="index.php?page=logout">ĐĂNG XUẤT</a> 
                <?php } ?>

                    <a href="index.php?page=payment">THANH TOÁN</a>
            </div>

            <div class="search-container">
                <button id="searchButton"><i class='bx bx-search'></i></button>
                <input type="text" id="searchTerm" placeholder="Thanh tìm kiếm...">
            </div>

            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

            <script src="asset/javascript/searchProduct.js"></script>   

            <div class="cart">

            <script src="../asset/javascript/cartDropDownFunction.js"></script>

            <script src="../asset/javascript/updateCartInfo.js"></script>

                <button class="btn-cart" id="cart-info">0 Sản Phẩm - 0 VND</button>
                <div class="cart-dropdown">
                    <div class="cart-items">
                        <!-- Các sản phẩm được thêm vào giỏ hàng sẽ được thêm vào đây  -->
                        <?php
                    
                            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

                            $stmt = $conn->prepare("SELECT * FROM addtocart WHERE usrID = ?");
                            $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
                            $stmt->execute();
                        
                            if ($stmt->rowCount() > 0) {
                                while ($row = $stmt->fetch()) {
                                    echo '                
                                        <div class="cart-item" bis_skin_checked="1" data-cart-id="' . $row['cartID'] . '">
                                            <img src="../asset/image/' . $row['image'] . '.jpg" alt="Gói thẻ bài Yugioh">
                                            <span>
                                                ' . $row['name'] . '
                                            </span>
                                            <label>
                                                ' . $row['price'] . ' VND
                                            </label>
                                            <div class="quantity" bis_skin_checked="1">' . $row['quantity'] . '</div>
                                            <button class="delete-button">Xóa</button>
                                        </div>';
                                }
                            } else {
                                echo '<div class="empty-cart">Không có sản phẩm trong giỏ hàng.</div>';
                            }

                        ?>
                  </div>
              </div>
          </div>
        </div>
        <div class="row3">
          <div class="containerr">
              <div class="main">
                <img src="asset/image/Yu-Gi-Oh-World-Championship-e1682035381458.png" class="img-feature"/>
                <div class="control prev">
                    <i class='bx bx-chevron-left size'></i>
                </div>
                <div class="control next">
                    <i class='bx bx-chevron-right size'></i>
                </div>
              </div>
              <div class="list-image">
                <div><img src="../asset/image/dfrvj2c-e834d761-32f0-4de7-8c43-5f1e808df8c7.png" alt=""></div>
                <div><img src="../asset/image/Yu-Gi-Oh-World-Championship-e1682035381458.png" alt=""></div>
                <div><img src="../asset/image/Steam-Deck-cover-photo.webp" alt=""></div>
                <div><img src="../asset/image/vfbyn2r06wx01.png" alt=""></div>
              </div>
          </div>

          <script src="../asset/javascript/slideShow.js"></script>
            
        </div>
    </header>