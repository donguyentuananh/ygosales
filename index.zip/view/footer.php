<footer align="center">
    <h2>M2 Duel Store - Cửa hàng trò chơi M2</h2>
      <h5>
        Số 186 Nguyễn Văn Khạ, KP3, TT. Củ Chi, Củ Chi, TP.HCM <br>
          Điện thoại hỗ trợ:  0938 144 068 - Kho hàng 028 3606 4150 <br>
                  Email 24/7: <a href="#">info@m2duelstore.com</a> <br>
                Facebook Chat: <a href="#">fb.com/m2duelstore</a> <br>
                  Giờ làm việc của kho hàng <br>
          7g30 - 11g30; 13g30 - 17g30 (nghỉ T7 và CN)
      </h5>
        <img src="asset/image/20150827110756-dathongbao.png" alt="" width="200px">
  </footer>