<div class="cart-manager-container">
            <label for="" class="laBel" align="center">QUẢN LÝ ĐƠN HÀNG</label>
            <hr style="margin-block: 20px;">

            <div class="cart-manager-fullbox">

                <div class="cart-manager-titlebox">
                    
                    <div class="name">Image</div>
                    <div class="address">Name</div>
                    <div class="phone-number">Quantity</div>
                    <div class="address">Price</div>
                    <div class="phone-number">Buy Again</div>
                    
                </div>

                <?php
                    if (isset($_REQUEST['pagi'])) {
                        $offset = ($_REQUEST['pagi'] - 1) * 10;
                    } else {
                        $offset = 0;
                    }
                    $stmt = $conn->query("SELECT * FROM buyhistory limit $offset,10");

                    // Initialize an associative array to store the sum of adjusted totals for each combination
                    $adjustedTotalSumByGroup = array();

                    $uniqueEntries = array();

                    while ($row = $stmt->fetch()) {
                        if ($row['usrID'] == $_SESSION['user_id']) {
                    
                                // Display the adjusted total
                                echo '
                                    <div class="cart-manager-box" data-bh-id="' . $row['BH_id'] . '">
                                        <div class="name"><img src="../asset/image/' . $row['image_prd'] . '.jpg" alt="Hộp thẻ bài Yugioh"></div>
                                        <div class="address">' . $row['name_prd'] . '</div>
                                        <div class="phone-number">' . $row['quantity_prd'] . '</div>
                                        <div class="address">' . $row['price_prd'] . '.000 VND</div>
                                        <div class="phone-number"><button class="buy-again-btn">Mua Lại</button></div>
                                    </div>
                                ';
                            }
                        }

                ?>

                <script>

                    $(document).ready(function() {
                        $('.buy-again-btn').on('click', function() {
                            var bhId = $(this).closest('.cart-manager-box').data('bh-id');
                            // You can add more data attributes if needed
                            
                            // Make an AJAX request to your PHP script
                            $.ajax({
                                type: 'POST',
                                url: '../model/buyagain.php', // Replace with your PHP script URL
                                data: { bhId: bhId },
                                success: function(response) {
                                    // Handle the response from the server (if needed)
                                    console.log(response);

                                    // Redirect to payment.php
                                    window.location.href = 'index.php?page=payment';
                                },
                                error: function(error) {
                                    console.error('Error:', error);
                                }
                            });
                        });
                    });

                </script>

            </div>

        </div>

    </div>