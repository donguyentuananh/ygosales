    <div class="prd-box2">
        <div class="add-btn">
            <a href="admin.php?page=addproduct">Thêm Sản Phẩm</a>
        </div>

        <div class="search-container">
            <button id="searchButton"><i class='bx bx-search'></i></button>
            <input type="text" id="searchTerm" placeholder="Thanh tìm kiếm...">
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <script src="../asset/javascript/addelSearch.js"></script>

        <label for="searchTerm" class="laBel">KẾT QUẢ TÌM KIẾM</label>
        <div id="results" class="card-box-full"></div>
        
        <label for="" class="laBel" align="center">QUẢN LÝ SẢN PHẨM</label>
        <div class="card-box-full">

                <?php
                    if (isset($_REQUEST['pagi'])){
                        $offset = ($_REQUEST['pagi']-1)*6;
                    }else $offset = 0;
                    $stmt = $conn->query("SELECT * FROM product ORDER BY prd_id DESC LIMIT $offset,6");
                    while($row = $stmt -> fetch()){
                        echo '                
                        <div class="card-box2">
                            <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">
                                <img src="../asset/image/' . $row['image'] . '.jpg" alt="Hộp thẻ bài Yugioh">
                            </a>                            
                            <span>
                                <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">' . $row['name'] . '</a>
                            </span>                            
                            <label>
                                <a href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">' . $row['price'] . ' VND</a>
                            </label>                           
                            <button class="add-to-cart delete-product" data-product-image="' . $row['image'] . '">Xóa</button>
                            <a class="update-btn" href="admin.php?page=updateproduct&id=' . $row['prd_id'] . '">Sửa</a>
                        </div>';    
                    }
                ?>

                <?php
                    // if (isset($_REQUEST['pagi'])){
                    //     $offset = ($_REQUEST['pagi']-1)*5;
                    // }else $offset = 0;
                    // $stmt = $conn -> query("SELECT * FROM product limit $offset,5");
                    // while($row = $stmt -> fetch()){
                    //     echo '                
                    //     <div class="card-box2">
                    //         <img src="../asset/image/' . $row['image'] . '.jpg" alt="' . $row['name'] . '">
                    //         <span>' . $row['name'] . '</span>
                    //         <label>' . $row['price'] . ' VND</label>
                    //         <button class="add-to-cart delete-product" data-product-image="' . $row['image'] . '">Xóa</button>
                    //         <button class="edit-btn">...</button>
                    //             <div class="dropdown-content" id="dropdown-content">
                    //                 <form action="../model/updateprocess.php" method="post" enctype="multipart/form-data">
                    //                     <div>
                    //                         <label for="name">Tên Sản Phẩm Hiện Tại: ' . $row['name'] . '</label>
                    //                         <input type="text" id="update_name" name="update_name" value="' . $row['name'] . '" required>
                    //                     </div>
                    //                     <div>
                    //                         <label for="price">Giá Hiện Tại: ' . $row['price'] . ' VND</label>
                    //                         <input type="text" id="update_price" name="update_price" value=' . $row['price'] . ' required>
                    //                     </div>
                    //                     <div>   
                    //                         <label for="img">Hình ảnh Hiện Tại: ' . $row['image'] . '.jpg</label>
                    //                         <input type="file" id="update_img" name="update_img" value=' . $row['image'] . ' required>
                    //                     </div>
                    //                     <input type="hidden" name="current_image" value=' . $row['image'] . '>  
                    //                     <button type="submit" name="update_submit">Cập Nhật</button>
                    //                 </form>
                    //             </div>
                    //     </div>';    
                    // }
                ?>

            <!-- <script>
                function deleteProduct(productId) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "../model/delete_product.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            // Xóa thành công
                            // Cập nhật giao diện người dùng (nếu cần)
                            alert("Sản phẩm đã bị xóa");
                        } else {
                            // Xảy ra lỗi khi xóa
                            alert("Đã xảy ra lỗi khi xóa sản phẩm");
                            }
                        }   
                    };
                        xhr.send("product_id=" + productId);
                    }
            </script> -->

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                var deleteButtons = document.querySelectorAll('.delete-product');
                deleteButtons.forEach(function(button) {
                    button.addEventListener('click', function() {
                        var productImage = this.getAttribute('data-product-image');
                        window.location.href = '../model/delete_product.php?product_image=' + productImage;
                        });
                    }); 
                });
            </script>

            <script>
                // JavaScript to show/hide the dropdown content
                document.addEventListener("DOMContentLoaded", function() {
                    var editButtons = document.querySelectorAll('.edit-btn');

                    editButtons.forEach(function(button) {
                        button.addEventListener('click', function() {
                            var dropdownContent = this.nextElementSibling;
                            dropdownContent.style.display = (dropdownContent.style.display === 'block') ? 'none' : 'block';
                        });
                    });
                });
            </script>

        </div>

        <div class="divide-page">
            <?php
                // $rows = $conn -> query("SELECT count(*) FROM product") -> fetchColumn();
                // $total_pages = ceil($rows / 10);
                // for($i = 1; $i <= $total_pages; $i++){
                //     echo "<a href='addel.php?pagi=$i'>$i</a>";
                // }

                $currentPage = isset($_GET['pagi']) ? $_GET['pagi'] : 1;
                $rows = $conn->query("SELECT count(*) FROM product")->fetchColumn();
                $total_pages = ceil($rows / 6);

                // Nút "Lùi một trang"
                if ($currentPage > 1) {
                    echo "<a href='admin.php?pagi=" . ($currentPage - 1) . "'><i class='bx bx-chevron-left'></i></a>";
                }

                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='admin.php?pagi=$i'>$i</a>";
                }

                // Nút "Tiến một trang"
                if ($currentPage < $total_pages) {
                    echo "<a href='admin.php?pagi=" . ($currentPage + 1) . "'><i class='bx bx-chevron-right' ></i></a>";
                }
            ?>
        </div>

    </div>
</div>