<div class="add-product">
            <?php
                // Check if user details are available
                if (isset($user)) {
            ?>
                <h2>Cập Nhật Người Dùng</h2>
                <form action="../model/updateuserprocess.php" method="post" enctype="multipart/form-data">
                    <div>
                        <label for="name">Name: <?php echo $user['name']; ?></label>
                        <input type="text" id="update_name" name="update_name" value="<?php echo $user['name']; ?>" required>
                    </div>
                    <div>
                        <label for="username">Username: <?php echo $user['username']; ?></label>
                        <input type="text" id="update_username" name="update_username" value="<?php echo $user['username']; ?>" required>
                    </div>
                    <div>   
                        <label for="email">Email: <?php echo $user['email']; ?></label>
                        <input type="text" id="update_email" name="update_email" value="<?php echo $user['email']; ?>" required>
                    </div>
                    <div>   
                        <label for="confirm">Password: <?php echo $user['confirm']; ?></label>
                        <input type="text" id="update_confirm" name="update_confirm" value="<?php echo $user['confirm']; ?>" required>
                    </div>
                    <div>
                        <?php
                            $stmt = $conn->prepare("SELECT * FROM userinfor WHERE usrID = ?");
                            $stmt->bindParam(1, $user['user_id'], PDO::PARAM_INT);
                            $stmt->execute();
                            $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
                        ?>

                        <?php if (!empty($userInfo['address'])) : ?>
                            <label for="">Address</label>
                            <input type="text" value="<?php echo $userInfo['address']; ?>" style="margin-bottom: 20px;">
                        <?php else : ?>
                            <label for="">Address</label>
                            <input type="text" disabled value="Chưa đăng ký địa chỉ" style="margin-bottom: 20px;">
                        <?php endif; ?>

                        <?php if (!empty($userInfo['phone_number'])) : ?>
                            <label for="">Phone Number</label>
                            <input type="text" value="<?php echo $userInfo['phone_number']; ?>">
                        <?php else : ?>
                            <label for="">Phone Number</label>
                            <input type="text" disabled value="Chưa đăng ký số điện thoại">
                        <?php endif; ?>
                    </div>
                    <div>   
                        <label for="role">Role: <?php echo $user['role']; ?></label>
                        <select id="update_role" name="update_role" required>
                            <option value="admin" <?php echo ($user['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                            <option value="user" <?php echo ($user['role'] == 'user') ? 'selected' : ''; ?>>User</option>
                        </select>
                    </div>
                    <div>   
                        <label for="status">Status: <?php echo $user['status']; ?></label>
                        <select id="update_status" name="update_status" required>
                            <option value="unlock" <?php echo ($user['status'] == 'unlock') ? 'selected' : ''; ?>>Unlock</option>
                            <option value="lock" <?php echo ($user['status'] == 'lock') ? 'selected' : ''; ?>>Lock</option>
                        </select>
                    </div>
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                    <button type="submit" name="update_submit">Cập Nhật</button>
                </form>
                <?php
                    } else {
                        // Handle case where user details are not available
                        echo "<p>user details not available.</p>";
                    }
                ?>
        </div>
    </div>
