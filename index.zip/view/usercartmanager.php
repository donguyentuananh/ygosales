<div class="cart-manager-container">
            <label for="" class="laBel" align="center">QUẢN LÝ ĐƠN HÀNG</label>
            <hr style="margin-block: 20px;">

            <div class="cart-manager-fullbox">

                <div class="cart-manager-titlebox">
                    <div class="name">Guest Name</div>
                    <div class="address">Address</div>
                    <div class="phone-number">Phone Number</div>
                    <div class="status">Status</div>
                    <div class="detail">Details</div>
                </div>

                <?php
                    if (isset($_REQUEST['pagi'])) {
                        $offset = ($_REQUEST['pagi'] - 1) * 10;
                    } else {
                        $offset = 0;
                    }
                    $stmt = $conn->query("SELECT * FROM cart limit $offset,10");

                    // Initialize an associative array to store the sum of adjusted totals for each combination
                    $adjustedTotalSumByGroup = array();

                    $uniqueEntries = array();

                    while ($row = $stmt->fetch()) {
                        if ($row['usrID'] == $_SESSION['user_id']) {
                            $key = $row['usrID'] . '-' . $row['guest_name'] . '-' . $row['address'] . '-' . $row['phonenumber'] . '-' . $row['status'] . '-' . $row['note'];
                    
                            if (!isset($uniqueEntries[$key])) {
                                $uniqueEntries[$key] = true;
                    
                                // Check the value of $row['status']
                                $statusText = ($row['status'] === 'paid') ? 'Đã thanh toán' : 'Chưa thanh toán';
                    
                                // Display the adjusted total
                                echo '
                                <div class="cart-manager-box">
                                    <div class="usrID" style="display: none;">' . $row['usrID'] . '</div>
                                    <div class="cart_id" style="display: none;">' . $row['cart_id'] . '</div>
                                    <div class="name">' . $row['guest_name'] . '</div>
                                    <div class="address">' . $row['address'] . '</div>
                                    <div class="phone-number">0' . $row['phonenumber'] . '</div>
                                    <div class="status">' . $statusText . '</div>
                                    <div class="detail"><a href="user.php?page=detailusercart&id=' . $row['cart_id'] . '">Chi tiết đơn hàng</a></div>
                                </div>';
                            }
                        }
                    }

                ?>

                <!-- <div class="cart-manager-box">
                    <div class="name">Đỗ Nguyễn Tuấn Anh</div>
                    <div class="address">165 Tân Sơn - P.15 - Q. Tân Bình</div>
                    <div class="phone-number">0329751394</div>
                    <div class="quantity">3</div>
                    <div class="total">1.000.000 VND</div>
                    <div class="status">Đã thanh toán</div>
                    <div class="detail"><a href="#">Chi tiết đơn hàng</a></div>
                </div> -->

            </div>

        </div>
        
    </div>