<div class="detailed-cart-manager-container">
        <?php
            // Check if user details are available
            if (isset($usercart)) {
        ?>
            <label for="" class="laBel" align="center">QUẢN LÝ CHI TIẾT ĐƠN HÀNG</label>
            <hr style="margin-block: 20px;">

            <div class="detailed-cart-manager-box">
                <div>
                    <label for="">User Name:</label>
                    <input type="text" disabled id="userNameInput" value="<?php echo $usercart['guest_name'] ?>">
                </div>
                <div>
                    <label for="">Address:</label>
                    <input type="text" id="addressInput" value="<?php echo $usercart['address'] ?>">
                </div>
                <div>
                    <label for="">Phone Number:</label>
                    <input type="text" id="phoneNumberInput" value="0<?php echo $usercart['phonenumber'] ?>">
                </div>
                <div>
                    <label for="">Delivery Cost:</label>
                    <input type="text" disabled id="deliveryCostInput" value="30.000 VND">
                </div>
                <div>
                    <label for="">Note:</label>
                    <textarea id="noteTextarea" name="" id="" cols="160" rows="5" style="padding: 10px;"><?php echo $usercart['note'] ?></textarea>
                </div>

                <button id="updateInforButton">Cập Nhật Thông Tin</button>

                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var waitingStatus = "<?php echo $usercart['waiting']; ?>";

                        // Check if waiting status is "delivering"
                        if (waitingStatus === 'unaccept') {
                            document.getElementById('addressInput').disabled = false;
                            document.getElementById('phoneNumberInput').disabled = false;
                            document.getElementById('noteTextarea').disabled = false;
                        }else if (waitingStatus === 'accept' || 'delivering'){
                            document.getElementById('addressInput').disabled = true;
                            document.getElementById('phoneNumberInput').disabled = true;
                            document.getElementById('noteTextarea').disabled = true;
                        }
                    });
                </script>

                <div class="detailed-cart-fullbox">

                    <!-- <div class="detailed-cart-title">
                        <div class="image">Image</div>
                        <div class="name">Product Name</div>
                        <div class="quantity">Quantity</div>
                        <div class="price">Price</div>
                        <div class="total-price">Total Price</div>
                        <div class="status">Status</div>
                        <div class="waiting">Waiting</div>
                    </div> -->

                    <label for="" class="laBel" align="center">CÁC SẢN PHẨM CỦA ĐƠN HÀNG</label>

                    <?php
                        if (isset($_REQUEST['pagi'])) {
                            $offset = ($_REQUEST['pagi'] - 1) * 10;
                        } else {
                            $offset = 0;
                        }
                        
                        // Assuming $cart has the necessary values
                        $usrID = $usercart['usrID'];
                        $guestName = $usercart['guest_name'];
                        $phonenumber = $usercart['phonenumber'];
                        $address = $usercart['address'];
                        $payment = $usercart['payment'];
                        $status = $usercart['status'];
                        $waiting = $usercart['waiting'];
                        $note = $usercart['note'];
                        
                        // Use prepared statements to prevent SQL injection
                        $stmt = $conn->prepare("SELECT * FROM cart WHERE usrID = ? AND guest_name = ? AND phonenumber = ? AND address = ? AND payment = ? AND status = ? AND waiting = ? AND note = ? LIMIT $offset, 10");
                        $stmt->execute([$usrID, $guestName, $phonenumber, $address, $payment, $status, $waiting, $note]);
                        
                        // Fetch and display the matching products
                        while ($row = $stmt->fetch()) {
                            $quantity = $row['quantity'];
                            $prdPrice = $row['prd_price'];
                            $totalPrdPrice = $row['total_prd_price'];
                            $statusText = ($status === 'paid') ? 'Đã thanh toán' : 'Chưa thanh toán';
                            
                            $waitingStatus = '';
                                if ($row['waiting'] === 'accept') {
                                    $waitingStatus = 'Đơn hàng đã được xác nhận';
                                } else if ($row['waiting'] === 'unaccept') {
                                    $waitingStatus = 'Đơn hàng chưa được xác nhận';
                                } else if ($row['waiting'] === 'delivering') {
                                    // If it's neither 'accept' nor 'unaccept', use the content in the 'waiting' column
                                    $waitingStatus = 'Đơn hàng đã được giao cho đơn vị vận chuyển';
                                } else if ($row['waiting'] === 'recieved') {
                                    $waitingStatus = 'Đã nhận được hàng';
                                }
                        
                            echo '
                                <div class="detailed-cart-box" data-cart-id="' . $row['cart_id'] . '">
                                    <div class="cart_id" style="display: none;">' . $row['cart_id'] . '</div>
                                    <div class="prdID" style="display: none;">' . $row['prdID'] . '</div>
                                    <img src="asset/image/' . $row['image_prd'] . '.jpg" alt="">
                                    <div class="name">' . $row['name_prd'] . '</div>
                                    <div class="quantity">' . $quantity . '</div>
                                    <div class="price">' . $prdPrice . '.000 VND</div>
                                    <div class="total-price">' . number_format($totalPrdPrice, 0, '.', '.') . '.000 VND</div>
                                    <div class="status">' . $statusText . '</div>
                                    <div class="waiting">' . $waitingStatus . '</div>
                                </div>';
                        }
                    ?>

                            <!-- // <div class="detailed-cart-box">
                            //     <img src="asset/image/a.jpg" alt="">
                            //     <div class="name">Hộp thẻ bài Yugioh - Stucture Deck Saga Of Blue Eyes</div>
                            //     <div class="quantity">10</div>
                            //     <div class="price">989.000 VND</div>
                            //     <div class="total-price">089.000 VND</div>
                            //     <div class="status">Đã thanh toán</div>
                            //     <div class="waiting">Đơn hàng đã được xác nhận</div>
                            // </div> -->

                </div>
                    
                    <?php

                        // Calculate and display the total
                        $totalStmt = $conn->prepare("SELECT SUM(total_prd_price) as total FROM cart WHERE usrID = ? AND guest_name = ? AND phonenumber = ? AND address = ? AND payment = ? AND status = ? AND waiting = ? AND note = ?");
                        $totalStmt->execute([$usrID, $guestName, $phonenumber, $address, $payment, $status, $waiting, $note]);
                        $totalRow = $totalStmt->fetch();
                        $totalAmount = $totalRow['total'] + 30;

                        // Determine the value based on the status
                        $totalValue = ($status === 'paid') ? '0 VND' : number_format($totalAmount, 0, '.', '.') . '.000 VND';

                        echo '
                            <div>
                                <label for="">Total:</label>
                                <input type="text" disabled value="' . $totalValue . '">
                            </div>';

                    ?>

                <div>
                    <label for="">Confirm Order:</label>
                    <select id="orderStatusSelect">
                        <option id="recieved" value="recieved">Đã nhận được hàng</option>
                    </select>
                </div>

                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var waitingStatus = "<?php echo $usercart['waiting']; ?>";

                        if (waitingStatus === 'delivering') {
                            document.getElementById('recieved').disabled = false;
                        }else if (waitingStatus === 'accept' || 'unaccept') {
                            document.getElementById('recieved').disabled = true;
                        }
                    });
                </script>

                <button id="updateButton">Cập Nhật Trạng Thái Đơn Hàng</button>

                <button id="deleteButton">Hủy Đơn Hàng</button>

                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

                <script>
                    $(document).ready(function() {
                        // Function to handle button click
                        $("#updateButton").click(function() {
                            // Get the selected value from the dropdown
                            var selectedStatus = $("#orderStatusSelect").val();

                            // Check if the selected option is disabled
                            if ($("#orderStatusSelect option:selected").prop("disabled")) {
                                // Display an alert or handle the case where the option is disabled
                                alert('Cập nhật không thành công vì đơn hàng chưa được chuyển đi');
                                return;
                            }

                            // Get all cart IDs
                            var cartIds = [];
                            $(".detailed-cart-box").each(function() {
                                cartIds.push($(this).data("cart-id"));
                            });

                            // Send an AJAX request to update 'waiting' column
                            $.ajax({
                                url: "../model/update_waiting2.php", // Replace with the actual update script
                                method: "POST",
                                data: {
                                    cartIds: cartIds,
                                    selectedStatus: selectedStatus
                                },
                                success: function(response) {
                                    // Handle success, if needed
                                    console.log(response);

                                    alert('Đơn hàng đã được nhận và lưu vào lịch sử mua hàng');

                                    // Redirect to user.php after successful deletion
                                    window.location = "user.php?page=usercartmanager";
                                },
                                error: function(xhr, status, error) {
                                    // Handle errors, if needed
                                    console.error(error);
                                }
                            });
                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {
                        // Function to handle button click
                        $("#updateInforButton").click(function() {
                            // Get the values from the input fields
                            var address = $("#addressInput").val();
                            var phoneNumber = $("#phoneNumberInput").val();
                            var note = $("#noteTextarea").val();

                            var waitingStatus = "<?php echo $usercart['waiting']; ?>";
                            if (waitingStatus === 'delivering' || 'accept') {
                                // Alert or handle the situation where deleting is not allowed
                                alert("Đơn hàng đã được giao cho đơn vị vận chuyển hoặc đã được xác nhận nên không thể cập nhật");
                                return;
                            }

                            // Get all cart IDs
                            var cartIds = [];
                            $(".detailed-cart-box").each(function() {
                                cartIds.push($(this).data("cart-id"));
                            });

                            // Send an AJAX request to update user information in the cart
                            $.ajax({
                                url: "../model/update_cartinfo.php", // Replace with the actual update script
                                method: "POST",
                                data: {
                                    cartIds: cartIds,
                                    address: address,
                                    phoneNumber: phoneNumber,
                                    note: note
                                },
                                success: function(response) {
                                    // Handle success, if needed
                                    console.log(response);

                                    // Reload the page after successful update
                                    location.reload();
                                },
                                error: function(xhr, status, error) {
                                    // Handle errors, if needed
                                    console.error(error);
                                }
                            });
                        });
                    });
                </script>

                <script>
                    $(document).ready(function() {
                        // Function to handle delete button click
                        $("#deleteButton").click(function() {
                            // Check if waiting status is "delivering"
                            var waitingStatus = "<?php echo $usercart['waiting']; ?>";
                            if (waitingStatus === 'delivering') {
                                // Alert or handle the situation where deleting is not allowed
                                alert("Đơn hàng đã được giao cho đơn vị vận chuyển nên không thể hủy");
                                return;
                            }

                            // Get all cart IDs
                            var cartIds = [];
                            $(".detailed-cart-box").each(function() {
                                cartIds.push($(this).data("cart-id"));
                            });

                            // Send an AJAX request to delete cart
                            $.ajax({
                                url: "../model/delete_cart.php", // Replace with the actual delete script
                                method: "POST",
                                data: {
                                    cartIds: cartIds
                                },
                                success: function(response) {
                                    // Handle success, if needed
                                    console.log(response);

                                    alert ('Đơn hàng đã được hủy');

                                    // Redirect to user.php after successful deletion
                                    window.location = "user.php?page=usercartmanager";
                                },
                                error: function(xhr, status, error) {
                                    // Handle errors, if needed
                                    console.error(error);
                                }
                            });
                        });
                    });
                </script>

            </div>

        <?php
            } else {
                // Handle case where user details are not available
                echo "<p>Cart details not available.</p>";
            }
        ?>

    </div>
    
</div>