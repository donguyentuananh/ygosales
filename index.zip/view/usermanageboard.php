<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Manager</title>
    <link rel="stylesheet" href="../asset/style5.css">
    <link rel="stylesheet" href="../asset/style4.css">
    <link rel="stylesheet" href="../asset/style7.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    <div class="admin-option-container">
        <div class="admin-option">
            <a href="index.php"><i class='bx bx-arrow-back'></i> Back To Home</a>
            <a href="#"><i class="bx bx-user-circle"></i> Manage Acccount</a>
            <?php
                if (isset($_SESSION['username']) && isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
                    echo '<a href="user.php?page=admin"><i class="bx bx-user"></i> Manage Admin</a>';
                }    
            ?>
            <a href="user.php?page=usercartmanager"><i class="bx bx-cart"></i> Manage Cart</a>
            <a href="user.php?page=buyhistory"><i class='bx bx-stopwatch' ></i> Buy History</a>
        </div>

