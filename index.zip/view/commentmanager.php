<div class="manage-user-container">

<h2>Comment Manager</h2>

<div class="search-container">
    <button id="searchButton"><i class='bx bx-search'></i></button>
    <input type="text" id="searchTerm" placeholder="Thanh tìm kiếm...">
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="../asset/javascript/commentSearch.js"></script>

<div class="user-title" align="center">
    <span>CommentID</span>
    <span>UserName</span>
    <span>UserID</span>
    <span>ProductID</span>
    <span>Comment</span>
    <span>Delete</span>
</div>
    <?php
        if (isset($_REQUEST['pagi'])){
            $offset = ($_REQUEST['pagi']-1)*10;
        }else $offset = 0;
            $stmt = $conn -> query("SELECT * FROM comment limit $offset,10");
        while($row = $stmt -> fetch()){
            echo '                
            <div class="user-content" align="center">
                <span>' . $row['cmt_id'] . '</span>
                <span>' . $row['name'] . '</span>
                <span>' . $row['usrID'] . '</span>
                <span>' . $row['prdID'] . '</span>
                <span>' . $row['cmt'] . '</span>
                <button class="delete-btn" data-cmtid="' . $row['cmt_id'] . '">
                    Delete
                </button>
            </div>';    
            }
        ?>

        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var deleteButtons = document.querySelectorAll('.delete-btn');

                deleteButtons.forEach(function (button) {
                    button.addEventListener('click', function () {
                        var cmtId = this.getAttribute('data-cmtid');

                        // Send an AJAX request to the server to delete the comment
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', '../model/delete_comment.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        xhr.onload = function () {
                            // Reload the page or update the comments without a page reload
                            // depending on your application's requirements
                            location.reload();
                        };
                        xhr.send('cmt_id=' + cmtId);
                    });
                });
            });
        </script>

        <label for="searchTerm" class="laBel">KẾT QUẢ TÌM KIẾM</label>
        <div id="results" class="card-box-full"></div>

        <div class="divide-page">
            <?php
                // $rows = $conn -> query("SELECT count(*) FROM product") -> fetchColumn();
                // $total_pages = ceil($rows / 10);
                // for($i = 1; $i <= $total_pages; $i++){
                //     echo "<a href='addel.php?pagi=$i'>$i</a>";
                // }

                $currentPage = isset($_GET['pagi']) ? $_GET['pagi'] : 1;
                $rows = $conn->query("SELECT count(*) FROM comment")->fetchColumn();
                $total_pages = ceil($rows / 10);

                // Nút "Lùi một trang"
                if ($currentPage > 1) {
                    echo "<a href='admin.php?pagi=" . ($currentPage - 1) . "'><i class='bx bx-chevron-left'></i></a>";
                }

                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='admin.php?pagi=$i'>$i</a>";
                }

                // Nút "Tiến một trang"
                if ($currentPage < $total_pages) {
                    echo "<a href='admin.php?pagi=" . ($currentPage + 1) . "'><i class='bx bx-chevron-right' ></i></a>";
                }
            ?>
        </div>
</div>
</div>