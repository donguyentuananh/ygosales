        <div class="add-product">
            <?php
                // Check if product details are available
                if (isset($product)) {
            ?>
                <h2>Cập Nhật Sản Phẩm</h2>
                <form action="../model/updateprocess.php" method="post" enctype="multipart/form-data">
                    <div>
                        <label for="name">Tên Sản Phẩm Hiện Tại: <?php echo $product['name']; ?></label>
                        <input type="text" id="update_name" name="update_name" value="<?php echo $product['name']; ?>" required>
                    </div>
                    <div>
                        <label for="price">Giá Hiện Tại: <?php echo $product['price']; ?> VND</label>
                        <input type="text" id="update_price" name="update_price" value="<?php echo $product['price']; ?>" required>
                    </div>
                    <div>   
                        <label for="quantity">Số Lượng Hiện Tại: <?php echo $product['quantity']; ?></label>
                        <input type="text" id="update_quantity" name="update_quantity" value="<?php echo $product['quantity']; ?>" required>
                    </div>
                    <div>   
                        <label for="img">Hình ảnh Hiện Tại: </label><img src="asset/image/<?php echo $product['image']; ?>.jpg" alt="Hộp thẻ bài Yugioh"> <br>
                        <input type="file" id="update_img" name="update_img" value="<?php echo $product['image']; ?>.jpg" required>
                    </div>
                    <input type="hidden" name="current_id" value="<?php echo $product['prd_id']; ?>">  
                    <input type="hidden" name="current_image" value="<?php echo $product['image']; ?>">  
                    <button type="submit" name="update_submit">Cập Nhật</button>
                </form>
                <?php
                    } else {
                        // Handle case where product details are not available
                        echo "<p>Product details not available.</p>";
                    }
                ?>
        </div>
    </div>
