    <div class="big-detail-container">
        <?php
        // Check if product details are available
        if (isset($product)) {

            // Retrieve user_id from the session
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

        ?>
            <div class="detail-container">
                <div class="big-image-prd">
                    <img src="asset/image/<?php echo $product['image']; ?>.jpg" alt="Product Image" width="320px" id="zoomImage">
                </div>
                <div class="big-in4-prd">
                    <div class="big-tit-prd">
                        <?php echo $product['name']; ?>
                    </div>
                    <div class="small-in4-prd">
                        Nhà Sản Xuất: KONAMI <br><br>
                        Số Lượng Sản Phẩm Trong Kho: <?php echo $product['quantity']; ?> <br><br>
                        <span><?php echo $product['price']; ?> VND</span> <br><br>
                        Mua sản phẩm bằng điểm thưởng:
                        Bạn cũng có thể dùng điểm thưởng để mua sản phẩm,
                        số điểm thưởng tích lũy để mua sản phẩm là: 0
                    </div>
                    <div class="add-to-cart-container">
                        <form action="../model/addtodetailcart.php" method="post">
                            <input type="text" name="prd_id" style="display: none;" value="<?php echo $product['prd_id']; ?>">
                            <!-- <input type="text" name="user_id" style="display: none;" value="<?php echo $_SESSION['user_id']; ?>"> -->
                            <input type="text" name="image" style="display: none;" value="<?php echo $product['image']; ?>">
                            <input type="text" name="name" style="display: none;" value="<?php echo $product['name']; ?>">
                            <input type="text" name="price" style="display: none;" value="<?php echo $product['price']; ?>">
                            <input type="text" name="current_quantity" style="display: none;" value="<?php echo $product['quantity']; ?>">
                            <label for="quantity">Số Lượng</label>
                            <input type="number" name="quantity" id="quantityInput" value="1">
                            <button type="submit">THÊM VÀO GIỎ</button>
                        </form>
                    </div>

                </div>
            </div>
            
            <div class="comment-container">
                <label for="">Gửi đánh giá cho sản phẩm này</label>
                <?php
                 if (!isset($_SESSION['username'])) { ?>
                    <a href="index.php?page=login">ĐĂNG NHẬP</a>
                <?php } else { ?>   
                    <h3>GỬI BÌNH LUẬN</h3>
                    <label for="">Please login or register to review</label>
                    <h5>Bình Luận</h5>
                    <hr width="875px" style="margin-top: 30px;">
                    <form method="post" action="../model/commentprocess.php" onsubmit="return validateComment()">
                        <input type="text" name="comment" id="commentInput" placeholder="Viết bình luận..." maxlength="400">
                        <input type="text" value="<?php echo $product['prd_id']; ?>" name="prd_id" style="display: none;">
                        <input type="text" value="<?php echo $_SESSION['username']; ?>" name="username" style="display: none;">
                        <input type="text" value="<?php echo $_SESSION['user_id']; ?>" name="user_id" style="display: none;">
                        <div class="post-btn">
                            <input type="submit" value="Đăng" name="submit_comment">
                        </div>
                    </form>

                    <script>
                        function validateComment() {
                            var commentInput = document.getElementById("commentInput").value;

                            if (commentInput.trim() === "") {
                                alert("Please enter a comment.");
                                return false; // Prevent form submission
                            }

                            // If the comment is not empty, the form will be submitted
                            return true;
                        }
                    </script>
                    
                    <?php
                        if (isset($_REQUEST['pagi'])) {
                            $offset = ($_REQUEST['pagi'] - 1) * 8;
                        } else {
                            $offset = 0;
                        }

                        // Fetch and display comments for the specific product
                        // $productId = $_SESSION['prd_id'];  // Assuming you have product_id in the session
                        $stmt = $conn->query("SELECT * FROM comment WHERE prdID = $productId ORDER BY cmt_id DESC");

                        while ($row = $stmt->fetch()) {
                            $commentUserID = $row['usrID']; // Assuming this is how you retrieve the user ID for the comment

                            // Check if the current user is the comment owner or an admin
                            $showDropdown = ($_SESSION['user_id'] === $commentUserID) || ($_SESSION['role'] === 'admin');

                            echo '
                            <div class="comment-box">
                                <div class="usr-cmt" id="comment-' . $row['cmt_id'] . '">
                                    <h4>' . $row['name'] . '</h4>
                                    <span>' . $row['cmt'] . '</span>
                                </div>

                                <div class="comment-edit">';
                            
                            if ($showDropdown) {
                                echo '
                                    <button onclick="toggleDropdown(' . $row['cmt_id'] . ')">...</button>
                                    <div class="dropdown-edit-cmt" id="dropdown-' . $row['cmt_id'] . '" align="center">
                                        <!-- Nội dung của dropdown -->
                                        <button onclick="deleteComment(' . $row['cmt_id'] . ')">
                                            Xóa bình luận
                                        </button>
                                    </div>';
                            }
                            
                            echo '
                                </div>
                            </div>';
                        }
                        ?>

                        <!-- Include jQuery -->
                        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

                        <script>
                            function deleteComment(commentId) {
                                // Confirm before deletion (optional)
                                if (confirm("Bạn có chắc chắn muốn xóa bình luận không?")) {
                                    // Send AJAX request to delete the comment
                                    $.ajax({
                                        type: "POST",
                                        url: "../model/deletecomment.php", // Replace with the actual file handling comment deletion
                                        data: { comment_id: commentId },
                                        success: function (response) {
                                            // Reload the entire page after successful deletion
                                            location.reload();
                                        },
                                        error: function (xhr, status, error) {
                                            console.error("Error deleting comment:", error);
                                            // Handle error if needed
                                        }
                                    });
                                }
                            }
                        </script>

                        <script>
                            function toggleDropdown(commentId) {
                                var commentDiv = document.getElementById('comment-' + commentId);
                                var dropdownDiv = document.getElementById('dropdown-' + commentId);

                                dropdownDiv.style.display = (dropdownDiv.style.display === 'none' || dropdownDiv.style.display === '') ? 'block' : 'none';
                            }

                            // Đóng dropdown nếu click bên ngoài
                            window.onclick = function(event) {
                                if (!event.target.matches('.comment-edit button')) {
                                    var dropdowns = document.querySelectorAll('.dropdown-edit-cmt');
                                    dropdowns.forEach(function(dropdown) {
                                        dropdown.style.display = 'none';
                                    });
                                }
                            }
                        </script>
                    
                <?php } ?>
            </div>
            
        <?php
        } else {
            // Handle case where product details are not available
            echo "<p>Product details not available.</p>";
        }
        ?>
    </div>