<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="../asset/style5.css">
    <link rel="stylesheet" href="../asset/style4.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>
    <div class="admin-option-container">
        <div class="admin-option">
            <a href="index.php"><i class='bx bx-arrow-back'></i> Back To Home</a>
            <a href="admin.php?page=addel"><i class='bx bx-box'></i> Manage Products</a>
            <a href="admin.php?page=usermanager"><i class='bx bx-user' ></i> Manage Users</a>
            <a href="admin.php?page=user"><i class='bx bx-user-circle' ></i> Manage Account</a>
            <a href="admin.php?page=cartmanager"><i class='bx bx-cart'></i> Manage Cart</a>
            <a href="admin.php?page=commentmanager"><i class='bx bx-chat'></i> Manage Comments</a>
        </div>