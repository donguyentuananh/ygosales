<?php
    session_start();
    require 'config/config.php';
    include 'model/conn.php';
    include 'view/manageboard.php';
    // include 'view/promo.php';
    // include 'view/bestseller.php';
    if(isset($_REQUEST['page'])) {
        $page = $_REQUEST['page'];
        switch($page) {
            case 'addel':
                include 'view/addel.php';
                break;
            case 'updateproduct':
                    // Check if 'id' parameter is set in the URL
                    if (isset($_GET['id'])) {
                        $productId = $_GET['id'];
                        
                        // Fetch and display product details based on $productId
                        $stmt = $conn->prepare("SELECT * FROM product WHERE prd_id = :id");
                        $stmt->bindParam(':id', $productId, PDO::PARAM_INT);
                        $stmt->execute();
                        
                        // Assuming only one product should be fetched, use fetch() instead of fetchAll()
                        $product = $stmt->fetch();

                        if ($product) {
                            // Include the detailproduct.php file and pass the product details
                            include 'view/updateproduct.php';
                        } else {
                            // Handle case where the product with the specified ID is not found
                            echo "Product not found";
                        }
                    } else {
                        // Handle case where 'id' parameter is not set in the URL
                        echo "Invalid product ID";
                    }
                break;
            case 'addproduct':
                include 'view/addproduct.php';
                break;
            // case 'detailproduct':
            //     // Check if 'id' parameter is set in the URL
            //     if (isset($_GET['id'])) {
            //         $productId = $_GET['id'];
                    
            //         // Fetch and display product details based on $productId
            //         $stmt = $conn->prepare("SELECT * FROM product WHERE prd_id = :id");
            //         $stmt->bindParam(':id', $productId, PDO::PARAM_INT);
            //         $stmt->execute();
                    
            //         // Assuming only one product should be fetched, use fetch() instead of fetchAll()
            //         $product = $stmt->fetch();

            //         if ($product) {
            //             // Include the detailproduct.php file and pass the product details
            //             include 'view/detailproduct.php';
            //         } else {
            //             // Handle case where the product with the specified ID is not found
            //             echo "Product not found";
            //         }
            //     } else {
            //         // Handle case where 'id' parameter is not set in the URL
            //         echo "Invalid product ID";
            //     }
            //     break;
            case 'usermanager':
                include 'view/usermanager.php';
                break;
            case 'updateuser':
                    // Check if 'id' parameter is set in the URL
                    if (isset($_GET['id'])) {
                        $userId = $_GET['id'];
                            
                        // Fetch and display user details based on $userId
                        $stmt = $conn->prepare("SELECT * FROM user WHERE user_id = :id");
                        $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
                        $stmt->execute();
                            
                        // Assuming only one user should be fetched, use fetch() instead of fetchAll()
                        $user = $stmt->fetch();

                        if ($user) {
                            // Include the detailuser.php file and pass the user details
                            include 'view/updateuser.php';
                        } else {
                            // Handle case where the user with the specified ID is not found
                            echo "User not found";
                        }
                    } else {
                        // Handle case where 'id' parameter is not set in the URL
                        echo "Invalid user ID";
                    }
                break;
            case 'commentmanager':
                include 'view/commentmanager.php';
                break;
            case 'cartmanager':
                include 'view/cartmanager.php';
                break;
            case 'user':
                echo "<script> window.location.href='user.php';</script>";
                break;
            case 'detailcartmanager':
                
                    if (isset($_GET['id'])) {
                        $cartId = $_GET['id'];
                            
                        
                        $stmt = $conn->prepare("SELECT * FROM cart WHERE cart_id = :id");
                        $stmt->bindParam(':id', $cartId, PDO::PARAM_INT);
                        $stmt->execute();
                            
                        
                        $cart = $stmt->fetch();

                        if ($cart) {
                            
                            include 'view/detailcartmanager.php';

                        } else {
                            
                            include 'view/cartmanager.php';
                        }
                    } else {
                        
                        echo "Invalid user ID";
                    }
                break;
            // case 'logout':
            //     echo "<script> window.location.href='model/logout.php';</script>";
            //     break;
            // case 'addel':
            //     echo "<script> window.location.href='view/addel.php';</script>";
            //     break;  
            // // case 'addproduct':
            // //     echo "<script> window.location.href='view/addproduct.php';</script>";
            // //     break;     
            // default:
            //     include 'view/product.php';
            //     break;
        }
    }
    else include 'view/addel.php';
?>